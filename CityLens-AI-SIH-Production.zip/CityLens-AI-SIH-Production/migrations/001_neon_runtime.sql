-- CityLens v3 runtime persistence for Neon PostgreSQL.
-- Each logical row is stored as JSONB to preserve the existing deterministic
-- domain engines, while revision columns provide optimistic concurrency control.
-- Exact row mutations are committed transactionally before HTTP responses.
CREATE TABLE IF NOT EXISTS citylens_documents (
  collection TEXT NOT NULL,
  id TEXT NOT NULL,
  data JSONB NOT NULL,
  revision BIGINT NOT NULL DEFAULT 1,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (collection, id)
);
ALTER TABLE citylens_documents ADD COLUMN IF NOT EXISTS revision BIGINT NOT NULL DEFAULT 1;
CREATE INDEX IF NOT EXISTS citylens_documents_collection_idx ON citylens_documents(collection);
CREATE INDEX IF NOT EXISTS citylens_documents_updated_idx ON citylens_documents(updated_at DESC);
CREATE INDEX IF NOT EXISTS citylens_documents_data_gin_idx ON citylens_documents USING GIN(data jsonb_path_ops);
-- Domain-specific lookup/uniqueness safeguards for frequently addressed entities.
CREATE UNIQUE INDEX IF NOT EXISTS citylens_users_email_unique
  ON citylens_documents ((lower(data->>'email'))) WHERE collection='users' AND data ? 'email';
CREATE UNIQUE INDEX IF NOT EXISTS citylens_incidents_code_unique
  ON citylens_documents ((data->>'code')) WHERE collection='incidents' AND data ? 'code';
CREATE UNIQUE INDEX IF NOT EXISTS citylens_tickets_code_unique
  ON citylens_documents ((data->>'code')) WHERE collection='tickets' AND data ? 'code';
CREATE UNIQUE INDEX IF NOT EXISTS citylens_settings_key_unique
  ON citylens_documents ((data->>'key')) WHERE collection='settings' AND data ? 'key';
CREATE UNIQUE INDEX IF NOT EXISTS citylens_integrations_key_unique
  ON citylens_documents ((data->>'key')) WHERE collection='integrations' AND data ? 'key';
CREATE INDEX IF NOT EXISTS citylens_incident_status_idx
  ON citylens_documents ((data->>'status')) WHERE collection='incidents';
CREATE INDEX IF NOT EXISTS citylens_ticket_status_idx
  ON citylens_documents ((data->>'status')) WHERE collection='tickets';
CREATE INDEX IF NOT EXISTS citylens_detection_incident_idx
  ON citylens_documents ((data->>'incidentId')) WHERE collection='detections';
CREATE INDEX IF NOT EXISTS citylens_observation_incident_idx
  ON citylens_documents ((data->>'incidentId')) WHERE collection='observations';
CREATE INDEX IF NOT EXISTS citylens_notification_user_idx
  ON citylens_documents ((data->>'forUserId')) WHERE collection='notifications';

CREATE TABLE IF NOT EXISTS citylens_meta (
  key TEXT PRIMARY KEY,
  value JSONB NOT NULL,
  revision BIGINT NOT NULL DEFAULT 1,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE citylens_meta ADD COLUMN IF NOT EXISTS revision BIGINT NOT NULL DEFAULT 1;

CREATE OR REPLACE FUNCTION citylens_assert_mutation(ok BOOLEAN) RETURNS BOOLEAN AS $$
BEGIN
  IF NOT ok THEN
    RAISE EXCEPTION 'CityLens concurrent update detected' USING ERRCODE = '40001';
  END IF;
  RETURN TRUE;
END;
$$ LANGUAGE plpgsql;
