'use strict';
require('../src/env');
if (!process.env.DATABASE_URL) { console.error('DATABASE_URL is required for migration.'); process.exit(1); }
(async()=>{
  const { neon } = require('@neondatabase/serverless');
  const sql = neon(process.env.DATABASE_URL);
  await sql`CREATE TABLE IF NOT EXISTS citylens_documents (collection TEXT NOT NULL,id TEXT NOT NULL,data JSONB NOT NULL,updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),PRIMARY KEY(collection,id))`;
  await sql`CREATE INDEX IF NOT EXISTS citylens_documents_collection_idx ON citylens_documents(collection)`;
  await sql`CREATE INDEX IF NOT EXISTS citylens_documents_updated_idx ON citylens_documents(updated_at DESC)`;
  await sql`CREATE TABLE IF NOT EXISTS citylens_meta (key TEXT PRIMARY KEY,value JSONB NOT NULL,updated_at TIMESTAMPTZ NOT NULL DEFAULT now())`;
  console.log('CityLens Neon runtime migration complete.');
})().catch(e=>{console.error(e);process.exit(1)});
