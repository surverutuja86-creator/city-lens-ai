'use strict';
require('../src/env');
const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const ROOT = path.join(__dirname, '..');
const required = [
  'server.js','api/index.js','vercel.json','.vercelignore','package.json','.env.example',
  'src/db.js','src/auth.js','src/storage.js','src/api.js','src/ai.js','src/demo_seed.js',
  'public/index.html','public/app.html','public/edge.html','public/css/app.css',
  'public/js/core.js','public/js/pages_a.js','public/js/pages_b.js','public/js/pages_c.js','public/js/pages_d.js',
  'migrations/001_neon_runtime.sql','README.md','docs/DEPLOYMENT.md','docs/ARCHITECTURE.md'
];
let failures = [];
for (const f of required) if (!fs.existsSync(path.join(ROOT, f))) failures.push(`missing required file: ${f}`);
for (const f of ['package.json','vercel.json']) {
  try { JSON.parse(fs.readFileSync(path.join(ROOT,f),'utf8')); } catch (e) { failures.push(`${f}: invalid JSON (${e.message})`); }
}
function walk(dir, out=[]) {
  for (const ent of fs.readdirSync(dir,{withFileTypes:true})) {
    if (['node_modules','.git','data'].includes(ent.name)) continue;
    const fp=path.join(dir,ent.name);
    ent.isDirectory()?walk(fp,out):out.push(fp);
  }
  return out;
}
for (const fp of walk(ROOT).filter(f=>f.endsWith('.js'))) {
  const r=cp.spawnSync(process.execPath,['-c',fp],{encoding:'utf8'});
  if (r.status!==0) failures.push(`syntax: ${path.relative(ROOT,fp)}\n${(r.stderr||r.stdout).trim()}`);
}
const front = ['public/js/core.js','public/js/pages_a.js','public/js/pages_b.js','public/js/pages_c.js','public/js/pages_d.js','public/edge.html']
  .map(f=>fs.readFileSync(path.join(ROOT,f),'utf8')).join('\n');
for (const [name,re] of [
  ['browser bearer token',/Authorization\s*:\s*[`'\"]Bearer/i],
  ['auth token in URL',/[?&]token=/i],
  ['legacy auth localStorage key',/clx?_token|cl_token/i],
]) if (re.test(front)) failures.push(`frontend security regression: ${name}`);
const pkg=JSON.parse(fs.readFileSync(path.join(ROOT,'package.json'),'utf8'));
if (!pkg.dependencies?.['@neondatabase/serverless']) failures.push('Neon dependency missing');
if (!pkg.dependencies?.['@vercel/blob']) failures.push('Vercel Blob dependency missing');
const env=fs.readFileSync(path.join(ROOT,'.env.example'),'utf8');
for (const k of ['DATABASE_URL=','AUTH_SECRET=','BLOB_ACCESS=']) if (!env.includes(k)) failures.push(`.env.example missing ${k}`);
if (failures.length) {
  console.error('\nCityLens static checks FAILED\n- '+failures.join('\n- '));
  process.exit(1);
}
console.log(`CityLens static checks passed (${walk(ROOT).filter(f=>f.endsWith('.js')).length} JavaScript files syntax-checked).`);
console.log('Run `npm run test:integration` for isolated HTTP auth/RBAC/session/security checks (it uses its own temporary data directory).');
