'use strict';
/**
 * Safe HTTP integration smoke test.
 * Always uses an isolated temporary local data directory and deliberately
 * ignores any developer/production DATABASE_URL so it can never seed or mutate
 * a real Neon database by accident.
 */
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');

const testDir = fs.mkdtempSync(path.join(os.tmpdir(), 'citylens-integration-'));
process.env.NODE_ENV = 'test';
process.env.VERCEL = '';
process.env.DATABASE_URL = '';          // prevents .env from loading a real DB URL
process.env.AUTH_SECRET = crypto.randomBytes(32).toString('hex');
process.env.CITYLENS_DATA_DIR = testDir;

const db = require('../src/db');
const { seed } = require('../src/seed');
const coverage = require('../src/coverage');
const { uid } = require('../src/util');
const { server } = require('../server');

function cookieFrom(res) { const v = res.headers.get('set-cookie'); return v ? v.split(';')[0] : ''; }
async function main() {
  await db.init();
  seed({ force: true });
  coverage.ensureSegments();
  await db.commit();
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  const port = server.address().port, base = `http://127.0.0.1:${port}`;
  const req = (url, opts = {}) => fetch(base + url, opts);

  let r = await req('/api/health');
  assert.equal(r.status, 200);
  const health = await r.json();
  assert.equal(health.server, 'online');
  assert.equal(health.database.backend, 'json-local');

  const email = `integration.${Date.now()}@example.com`;
  r = await req('/api/auth/register', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ name: 'Integration User', email, password: 'StrongPass1' }) });
  assert.equal(r.status, 201);
  const setCookie = r.headers.get('set-cookie') || '';
  assert(setCookie.includes('HttpOnly'));
  assert(setCookie.includes('SameSite=Lax'));
  let cookie = cookieFrom(r);
  assert(cookie.includes('citylens_session='));
  let j = await r.json();
  assert.equal(j.user.role, 'analyst');
  assert(!('token' in j));

  r = await req('/api/auth/me', { headers: { cookie } });
  assert.equal(r.status, 200);
  j = await r.json();
  assert.equal(j.user.email, email);

  r = await req('/api/dashboard/stats', { headers: { cookie } });
  assert.equal(r.status, 200);

  // Analysts do not receive the staff email directory.
  r = await req('/api/users', { headers: { cookie } });
  assert.equal(r.status, 200);
  j = await r.json();
  assert.deepEqual(j.rows, []);

  // Cookie-authenticated cross-origin writes are rejected.
  r = await req('/api/auth/logout', { method: 'POST', headers: { cookie, origin: 'https://evil.example' } });
  assert.equal(r.status, 403);

  // Broken-object-level auth regression: another user's notification cannot be changed.
  const admin = db.getBy('users', 'email', 'admin@citylens.ai');
  const privateNotification = db.insert('notifications', { id: uid('NTF'), kind: 'PRIVATE_TEST', severity: 'low', title: 'Private', message: '', entityType: null, entityId: null, forRole: null, forUserId: admin.id, department: null, isRead: false, archived: false, createdAt: new Date().toISOString() });
  await db.commit();
  r = await req(`/api/notifications/${privateNotification.id}/read`, { method: 'PATCH', headers: { cookie, 'content-type': 'application/json' }, body: '{}' });
  assert.equal(r.status, 404);

  // Local object-storage traversal is blocked.
  r = await req('/api/object?key=../citylens.json', { headers: { cookie } });
  assert.equal(r.status, 400);

  r = await req('/api/users', { method: 'POST', headers: { cookie, 'content-type': 'application/json' }, body: JSON.stringify({ name: 'Nope', email: 'x@y.com', password: 'StrongPass1', role: 'admin' }) });
  assert.equal(r.status, 403);

  r = await req('/api/auth/register', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ name: 'Dup', email: email.toUpperCase(), password: 'StrongPass1' }) });
  assert.equal(r.status, 409);

  r = await req('/api/auth/logout', { method: 'POST', headers: { cookie } });
  assert.equal(r.status, 200);
  cookie = cookieFrom(r);
  assert(cookie.includes('citylens_session='));
  r = await req('/api/auth/me', { headers: { cookie } });
  assert.equal(r.status, 401);

  r = await req('/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email, password: 'StrongPass1' }) });
  assert.equal(r.status, 200);
  cookie = cookieFrom(r);
  r = await req('/api/dashboard/stats', { headers: { cookie } });
  assert.equal(r.status, 200);

  // Admin user-management validates passwords too.
  r = await req('/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email: 'admin@citylens.ai', password: 'admin123' }) });
  assert.equal(r.status, 200);
  const adminCookie = cookieFrom(r);
  r = await req('/api/users', { method: 'POST', headers: { cookie: adminCookie, 'content-type': 'application/json' }, body: JSON.stringify({ name: 'Weak Account', email: 'weak@example.com', password: 'weak', role: 'analyst' }) });
  assert.equal(r.status, 400);
  r = await req('/api/users', { headers: { cookie: adminCookie } });
  assert.equal(r.status, 200);
  j = await r.json();
  assert(j.rows.some(u => u.email === 'admin@citylens.ai'));

  r = await req('/app');
  assert.equal(r.status, 200);
  const app = await r.text();
  assert(app.includes('pages_d.js'));
  r = await req('/js/pages_d.js');
  assert.equal(r.status, 200);

  console.log('integration ok: health, signup, HttpOnly restore, RBAC, directory privacy, CSRF-origin guard, notification BOLA guard, traversal guard, duplicate signup, logout/relogin, admin password policy, app assets');
}

main().catch(e => { console.error(e); process.exitCode = 1; }).finally(async () => {
  try { if (server.listening) await new Promise(r => server.close(r)); } catch {}
  try { fs.rmSync(testDir, { recursive: true, force: true }); } catch {}
});
