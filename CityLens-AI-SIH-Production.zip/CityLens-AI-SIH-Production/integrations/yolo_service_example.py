"""
CityLens AI — reference external YOLO analysis service (FastAPI + Ultralytics).

Local example:
    pip install fastapi uvicorn ultralytics opencv-python requests
    uvicorn yolo_service_example:app --port 8001
    YOLO_SERVICE_URL=http://localhost:8001 node server.js

Production CityLens sends `sourceUrl` as a short-lived signed Vercel Blob URL.
For same-machine local development it may send an absolute `filePath` instead.
Replace the example model with your fine-tuned road-defect weights before making
accuracy claims.
"""
import datetime
import os
import tempfile
from urllib.parse import urlparse

import requests
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

try:
    from ultralytics import YOLO
    MODEL = YOLO("yolov8n.pt")  # Replace with road-defect weights such as best.pt.
except Exception:
    MODEL = None

app = FastAPI(title="CityLens YOLO service")

CLASS_MAP = {
    "pothole": "pothole",
    "crack": "road_crack",
    "car": "vehicle",
    "truck": "vehicle",
    "bus": "vehicle",
    "motorcycle": "vehicle",
    "person": "pedestrian_risk",
}

def severity(conf: float) -> str:
    return "critical" if conf > 0.92 else "high" if conf > 0.8 else "medium" if conf > 0.6 else "low"

class Job(BaseModel):
    jobId: str
    filename: str
    sourceUrl: str | None = None
    filePath: str | None = None
    latitude: float | None = None
    longitude: float | None = None
    routeCode: str | None = None

def obtain_source(job: Job) -> tuple[str, str | None]:
    """Return (path, temporary_path_to_delete)."""
    if job.filePath and os.path.isfile(job.filePath):
        return job.filePath, None
    if not job.sourceUrl:
        raise HTTPException(status_code=400, detail="sourceUrl or readable local filePath is required")
    parsed = urlparse(job.sourceUrl)
    if parsed.scheme not in {"https", "http"}:
        raise HTTPException(status_code=400, detail="Unsupported sourceUrl scheme")
    # In production, restrict accepted hostnames to your own Blob/store allowlist.
    suffix = os.path.splitext(job.filename or "")[1] or ".bin"
    with requests.get(job.sourceUrl, timeout=90, stream=True, allow_redirects=False) as response:
        response.raise_for_status()
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
            for chunk in response.iter_content(chunk_size=1024 * 1024):
                if chunk:
                    tmp.write(chunk)
            return tmp.name, tmp.name

@app.post("/analyze")
def analyze(job: Job):
    if MODEL is None:
        raise HTTPException(status_code=503, detail="YOLO model is not loaded")

    results, frames = [], 0
    path, temp_path = obtain_source(job)
    try:
        for prediction in MODEL.predict(source=path, stream=True, vid_stride=5, verbose=False):
            frames += 1
            for box in prediction.boxes:
                name = MODEL.names[int(box.cls)]
                dtype = CLASS_MAP.get(name)
                if not dtype:
                    continue
                conf = float(box.conf)
                x1, y1, x2, y2 = [float(v) for v in box.xyxyn[0]]
                results.append({
                    "detection_type": dtype,
                    "confidence": round(conf, 3),
                    "frame_number": frames * 5,
                    "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    "latitude": job.latitude,
                    "longitude": job.longitude,
                    "bounding_box": {"x": x1, "y": y1, "w": x2 - x1, "h": y2 - y1},
                    "severity": severity(conf),
                    # Upload authorized annotated evidence separately and return its URL if desired.
                })
    finally:
        if temp_path:
            try:
                os.unlink(temp_path)
            except OSError:
                pass

    return {"fps": None, "inferenceMs": None, "framesProcessed": frames * 5, "results": results[:40]}
