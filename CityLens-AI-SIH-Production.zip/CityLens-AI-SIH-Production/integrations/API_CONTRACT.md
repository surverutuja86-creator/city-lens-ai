# External YOLO analysis service contract

CityLens is engine-agnostic. `src/ai.js` calls the configured engine and normalises its output; the UI does not need engine-specific code.

## Request (CityLens → inference service)
When `YOLO_SERVICE_URL` is set and the user selects the external engine, CityLens POSTs to `{YOLO_SERVICE_URL}/analyze`:

```json
{
  "jobId": "JOB-XXXX",
  "filename": "dashcam_clip.mp4",
  "sourceUrl": "https://<private-blob>...?signed=short-lived",
  "filePath": null,
  "latitude": 18.5289,
  "longitude": 73.8744,
  "routeCode": "R-05"
}
```

- **Production:** `sourceUrl` is a short-lived, GET-only signed Vercel Blob URL. No CityLens session token is placed in the URL.
- **Local development:** `filePath` may contain an absolute local path when the inference service runs on the same machine. `sourceUrl` may be null.
- The inference service must not log signed URLs or persist them after processing.

## Response (inference service → CityLens)
```json
{
  "fps": 24.6,
  "inferenceMs": 38,
  "framesProcessed": 2150,
  "results": [
    {
      "detection_type": "pothole",
      "confidence": 0.942,
      "frame_number": 512,
      "timestamp": "2026-09-03T09:41:22Z",
      "latitude": 18.5291,
      "longitude": 73.8747,
      "bounding_box": { "x": 0.41, "y": 0.63, "w": 0.16, "h": 0.11 },
      "severity": "high",
      "evidence_image": "https://your-authorized-store/example.jpg"
    }
  ]
}
```

- `detection_type` should be one of: `pothole`, `road_crack`, `road_damage`, `waterlogging`, `missing_divider`, `damaged_divider`, `missing_zebra`, `sign_damage`, `vehicle`, `congestion`, `pedestrian_risk`, `obstruction`, `accident`, `other`.
- `severity` may be `low`, `medium`, `high`, or `critical`. It is optional.
- `bounding_box` is normalised 0–1 (`x`,`y` = top-left).
- `evidence_image` is optional. If omitted, CityLens leaves that evidence field empty; it does **not** fabricate an image.
- Maximum inference request time is currently **180 seconds**.
- A timeout, unreachable service, invalid JSON, or non-200 response marks the AI job as **failed** and produces an operator-visible failure notification. CityLens deliberately does **not** fall back to fake/mock detections.

## Security expectations

- Deploy the inference endpoint over HTTPS in production.
- Keep the service private or add service-to-service authentication before exposing it publicly.
- Validate file type and size again inside the inference service.
- Never accept arbitrary server-side filesystem paths from untrusted public clients; `filePath` is intended only for same-machine local development.
- Do not include CityLens browser/session tokens in inference URLs.
