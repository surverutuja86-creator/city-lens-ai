'use strict';
/**
 * Ingestion layer — the single door through which real events enter CityLens.
 * · validates every field (class taxonomy, confidence 0–1, lat/lng ranges, timestamps)
 * · idempotent: an eventUuid seen before returns the original record (safe edge retries)
 * · pipes accepted detections through dedupe → scoring → verification hooks
 */
const db = require('./db');
const geo = require('./geo');
const { uid } = require('./util');
const dedupe = require('./dedupe');
const verify = require('./verify');
const { audit } = require('./audit');

const CATEGORIES = ['pothole', 'road_crack', 'road_damage', 'waterlogging', 'missing_divider',
  'damaged_divider', 'missing_zebra', 'sign_damage', 'obstruction', 'accident', 'congestion',
  'pedestrian_risk', 'vehicle', 'garbage_overflow', 'missing_sign', 'rash_driving', 'road_hazard', 'other'];

let emit = () => { };
function bindEmitter(fn) { emit = fn; }

function bad(field, msg) { return { ok: false, code: 400, error: `${field}: ${msg}` }; }
function num(v) { return typeof v === 'number' && isFinite(v); }

function locationNameFor(lat, lng) {
  const near = geo.nearestSegment(db.all('road_segments'), lat, lng, 140);
  return near ? near.segment.roadName : null;
}

/**
 * Ingest one detection event. src: 'upload' | 'edge' | 'external'.
 * ev: { eventUuid?, class, confidence, latitude, longitude, timestamp?,
 *       bbox?, frameNumber?, deviceId?, busId?, routeId?, jobId?,
 *       modelName, modelVersion, inferenceMs?, evidenceImage?, evidenceCrop? }
 */
function ingestDetection(ev, src, actor) {
  if (!ev || typeof ev !== 'object') return bad('body', 'missing');
  const cat = ev.class || ev.category;
  if (!CATEGORIES.includes(cat)) return bad('class', `must be one of ${CATEGORIES.join(', ')}`);
  if (!num(ev.confidence) || ev.confidence < 0 || ev.confidence > 1) return bad('confidence', 'number in [0,1] required');
  if (!num(ev.latitude) || Math.abs(ev.latitude) > 90) return bad('latitude', 'invalid');
  if (!num(ev.longitude) || Math.abs(ev.longitude) > 180) return bad('longitude', 'invalid');
  if (!ev.modelName) return bad('modelName', 'required — detections must state their model of origin');
  const ts = ev.timestamp ? new Date(ev.timestamp) : new Date();
  if (isNaN(ts)) return bad('timestamp', 'invalid ISO datetime');

  // idempotency
  const eventUuid = ev.eventUuid || null;
  if (eventUuid) {
    const seen = db.getBy('ingest_events', 'eventUuid', eventUuid);
    if (seen) {
      const prior = db.get('detections', seen.detectionId);
      return { ok: true, idempotent: true, detection: prior, incidentId: prior && prior.incidentId };
    }
  }

  const det = db.insert('detections', {
    id: uid('DET'), eventUuid,
    sourceType: src, sourceId: ev.deviceId || ev.jobId || (actor && actor.id) || null,
    deviceId: ev.deviceId || null, busId: ev.busId || null, routeId: ev.routeId || null,
    jobId: ev.jobId || null,
    category: cat, confidence: Math.round(ev.confidence * 1000) / 1000,
    boundingBox: ev.bbox || ev.boundingBox || null, frameNumber: ev.frameNumber ?? null,
    latitude: ev.latitude, longitude: ev.longitude,
    locationName: ev.locationName || locationNameFor(ev.latitude, ev.longitude),
    evidenceImage: ev.evidenceImage || null, evidenceCrop: ev.evidenceCrop || null,
    modelName: ev.modelName, modelVersion: ev.modelVersion || null,
    inferenceMs: num(ev.inferenceMs) ? ev.inferenceMs : null,
    privacyStatus: ev.privacyStatus || 'unavailable', // honest default — no blur model configured
    validationState: 'UNREVIEWED',
    timestamp: ts.toISOString(), createdAt: new Date().toISOString(),
  });
  if (eventUuid) db.insert('ingest_events', { id: uid('IEV'), eventUuid, detectionId: det.id, at: det.createdAt });

  const piped = dedupe.processDetection(det);
  if (piped.prevStatus === 'AWAITING_VERIFICATION') verify.onRedetection(piped.incident, det);

  emit('detection', { ...det, incidentId: piped.incident.id, incidentCode: piped.incident.code, merged: piped.merged });
  if (!piped.merged) emit('incident', { id: piped.incident.id, code: piped.incident.code, status: piped.incident.status, category: piped.incident.category, latitude: piped.incident.latitude, longitude: piped.incident.longitude, impactScore: piped.incident.impactScore });
  return { ok: true, detection: det, incident: db.get('incidents', piped.incident.id), merged: piped.merged, matchRadiusM: piped.radiusM };
}

/** Ingest a telemetry ping. src: 'browser' | 'edge' | 'trace_import' | 'hardware'. */
function ingestTelemetry(ev, src) {
  if (!num(ev.latitude) || Math.abs(ev.latitude) > 90) return bad('latitude', 'invalid');
  if (!num(ev.longitude) || Math.abs(ev.longitude) > 180) return bad('longitude', 'invalid');
  if (!ev.busId && !ev.deviceId) return bad('busId/deviceId', 'at least one source id required');
  const ts = ev.timestamp ? new Date(ev.timestamp) : new Date();
  if (isNaN(ts)) return bad('timestamp', 'invalid');
  if (eventDupe(ev.eventUuid)) return { ok: true, idempotent: true };

  const row = db.insert('telemetry', {
    id: uid('TLM'), eventUuid: ev.eventUuid || null,
    busId: ev.busId || null, deviceId: ev.deviceId || null, routeId: ev.routeId || null,
    latitude: ev.latitude, longitude: ev.longitude,
    speed: num(ev.speed) ? ev.speed : null, heading: num(ev.heading) ? ev.heading : null,
    accuracyM: num(ev.accuracy) ? ev.accuracy : null,
    source: src, timestamp: ts.toISOString(), receivedAt: new Date().toISOString(),
  });
  if (ev.eventUuid) db.insert('ingest_events', { id: uid('IEV'), eventUuid: ev.eventUuid, telemetryId: row.id, at: row.receivedAt });

  // update fleet last-known (real heartbeat, provenance kept)
  if (ev.busId) {
    const bus = db.getBy('buses', 'busCode', ev.busId) || db.get('buses', ev.busId);
    if (bus) db.update('buses', bus.id, { latitude: row.latitude, longitude: row.longitude, speed: row.speed, heading: row.heading, lastTelemetryAt: row.timestamp, telemetrySource: src, status: 'active' });
  }
  if (ev.deviceId) {
    const dev = db.getBy('devices', 'deviceCode', ev.deviceId) || db.get('devices', ev.deviceId);
    if (dev) db.update('devices', dev.id, { lastHeartbeatAt: row.timestamp, connectionStatus: 'online', lastLatitude: row.latitude, lastLongitude: row.longitude });
  }
  emit('telemetry', row);
  return { ok: true, telemetry: row };
}

function eventDupe(eventUuid) { return eventUuid ? !!db.getBy('ingest_events', 'eventUuid', eventUuid) : false; }

module.exports = { ingestDetection, ingestTelemetry, bindEmitter, CATEGORIES };
