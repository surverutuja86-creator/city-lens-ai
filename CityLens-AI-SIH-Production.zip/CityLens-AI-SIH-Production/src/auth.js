'use strict';
/** CityLens authentication & RBAC. */
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const SECRET_FILE = path.join(process.env.CITYLENS_DATA_DIR ? path.resolve(process.env.CITYLENS_DATA_DIR) : path.join(__dirname, '..', 'data'), '.secret');
let SECRET = process.env.AUTH_SECRET || process.env.CITYLENS_SECRET || null;
function secret() {
  if (SECRET) return SECRET;
  if (process.env.NODE_ENV === 'production' || process.env.VERCEL) {
    throw new Error('AUTH_SECRET is required in production. Generate a long random value and configure it in Vercel Environment Variables.');
  }
  try {
    fs.mkdirSync(path.dirname(SECRET_FILE), { recursive: true });
    if (fs.existsSync(SECRET_FILE)) SECRET = fs.readFileSync(SECRET_FILE, 'utf8').trim();
    if (!SECRET) {
      SECRET = crypto.randomBytes(32).toString('hex');
      fs.writeFileSync(SECRET_FILE, SECRET, { mode: 0o600 });
    }
  } catch { SECRET = crypto.randomBytes(32).toString('hex'); }
  return SECRET;
}

function hashPassword(plain) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(plain), salt, 32).toString('hex');
  return `scrypt$${salt}$${hash}`;
}
function verifyPassword(plain, stored) {
  try {
    const [algo, salt, hash] = String(stored).split('$');
    if (algo !== 'scrypt' || !salt || !hash) return false;
    const test = crypto.scryptSync(String(plain), salt, 32).toString('hex');
    const a = Buffer.from(hash, 'hex'), b = Buffer.from(test, 'hex');
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  } catch { return false; }
}

const b64u = buf => Buffer.from(buf).toString('base64url');
function sign(payload, ttlMs = 12 * 60 * 60 * 1000) {
  const header = b64u(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const body = b64u(JSON.stringify({ ...payload, iat: Date.now(), exp: Date.now() + ttlMs }));
  const sig = crypto.createHmac('sha256', secret()).update(`${header}.${body}`).digest('base64url');
  return `${header}.${body}.${sig}`;
}
function verify(token) {
  try {
    const [header, body, sig] = String(token || '').split('.');
    if (!header || !body || !sig) return null;
    const expect = crypto.createHmac('sha256', secret()).update(`${header}.${body}`).digest('base64url');
    const a = Buffer.from(sig), b = Buffer.from(expect);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (!payload.exp || Date.now() > payload.exp) return null;
    return payload;
  } catch { return null; }
}

function sessionCookie(token, maxAgeSec = 12 * 60 * 60) {
  const secure = process.env.NODE_ENV === 'production' || !!process.env.VERCEL;
  return `citylens_session=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAgeSec}${secure ? '; Secure' : ''}`;
}
function assertConfigured() { secret(); return true; }
function clearSessionCookie() {
  const secure = process.env.NODE_ENV === 'production' || !!process.env.VERCEL;
  return `citylens_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure ? '; Secure' : ''}`;
}

const ROLES = {
  admin: { label: 'System Admin' }, operator: { label: 'Command Centre Operator' },
  officer: { label: 'Department Officer' }, field: { label: 'Field Worker' },
  reviewer: { label: 'AI Reviewer' }, analyst: { label: 'Read-Only Analyst' },
};
const PERMS = {
  'incident.review': ['operator', 'reviewer', 'officer'], 'incident.assign': ['operator', 'officer'],
  'ticket.manage': ['operator', 'officer'], 'ticket.fieldwork': ['field', 'officer'],
  'repair.submit': ['field', 'officer'], 'detection.review': ['reviewer', 'operator'],
  'analysis.run': ['operator', 'officer', 'field', 'reviewer'], 'telemetry.ingest': ['operator', 'officer', 'field'],
  'fleet.manage': [], 'zones.manage': ['operator'], 'sla.manage': [], 'users.manage': [],
  'settings.manage': [], 'integrations.manage': [], 'audit.read': ['operator'],
  'notifications.manage': ['operator', 'officer', 'field', 'reviewer'],
};
function can(role, perm) { if (role === 'admin') return true; const list = PERMS[perm]; return !!list && list.includes(role); }

module.exports = { hashPassword, verifyPassword, sign, verify, sessionCookie, clearSessionCookie, assertConfigured, ROLES, PERMS, can };
