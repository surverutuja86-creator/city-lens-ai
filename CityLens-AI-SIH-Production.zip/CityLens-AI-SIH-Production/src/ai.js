'use strict';
/**
 * CityLens AI job service.
 * Real upload -> real analyzer -> evidence -> publish into ingest pipeline.
 * On Vercel, work completes inside the request lifecycle (no unreliable background
 * setImmediate after response). Durable object copies are stored in Vercel Blob
 * when a Vercel Blob store is connected (OIDC or legacy token); local development uses data/objects.
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawnSync } = require('child_process');
const db = require('./db');
const storage = require('./storage');
const { uid } = require('./util');
const cv = require('./cv');
const ingest = require('./ingest');
const verify = require('./verify');
const { audit } = require('./audit');

const WORK_ROOT = process.env.VERCEL ? path.join(os.tmpdir(), 'citylens') : (process.env.CITYLENS_DATA_DIR ? path.resolve(process.env.CITYLENS_DATA_DIR) : path.join(__dirname, '..', 'data')); 
const UPLOAD_DIR = path.join(WORK_ROOT, 'uploads');
const EVIDENCE_DIR = path.join(WORK_ROOT, 'evidence');
const MAX_BYTES = 120 * 1024 * 1024;
const EXT_OK = ['.mp4', '.mov', '.avi', '.mkv', '.webm', '.jpg', '.jpeg', '.png'];

let emit = () => {};
function bindEmitter(fn) { emit = fn; }
function dirBytes(dir) { try { return fs.readdirSync(dir).reduce((a, f) => a + fs.statSync(path.join(dir, f)).size, 0); } catch { return 0; } }
function mimeFor(ext) { return ({'.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.mp4':'video/mp4','.mov':'video/quicktime','.avi':'video/x-msvideo','.mkv':'video/x-matroska','.webm':'video/webm'})[ext] || 'application/octet-stream'; }

async function createJobFromUpload(buffer, meta, actor) {
  const ext = path.extname(meta.filename || '').toLowerCase();
  if (!EXT_OK.includes(ext)) return { ok: false, code: 400, error: `Unsupported file type ${ext || '(none)'} — allowed: ${EXT_OK.join(' ')}` };
  if (!buffer || !buffer.length) return { ok: false, code: 400, error: 'Empty upload' };
  if (buffer.length > MAX_BYTES) return { ok: false, code: 413, error: 'File exceeds 120 MB limit' };

  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
  const id = uid('JOB');
  const stored = `${id}${ext}`;
  const localFile = path.join(UPLOAD_DIR, stored);
  fs.writeFileSync(localFile, buffer);

  let durable = null;
  try { durable = await storage.putBuffer(`uploads/${stored}`, buffer, mimeFor(ext)); }
  catch (err) {
    if (process.env.VERCEL) return { ok: false, code: 503, error: `Persistent object storage failed: ${err.message}` };
  }

  const job = db.insert('ai_jobs', {
    id, filename: meta.filename, storedFile: durable?.url || stored, storagePathname: durable?.pathname || null, filePath: localFile,
    storageBackend: durable?.backend || 'local-working-file',
    sizeBytes: buffer.length, kind: ['.jpg','.jpeg','.png'].includes(ext) ? 'image' : 'video',
    sourceKind: meta.sourceKind || 'upload',
    isDemo: meta.sourceKind === 'synthetic_test',
    engine: meta.engine === 'yolo-external' ? 'yolo-external' : 'classical-cv-v1',
    latitude: Number.isFinite(meta.latitude) ? meta.latitude : null,
    longitude: Number.isFinite(meta.longitude) ? meta.longitude : null,
    routeCode: meta.routeCode || null, deviceId: meta.deviceId || null, busId: meta.busId || null,
    scanRadiusM: 60, status: 'queued', error: null, results: null,
    framesProcessed: null, avgInferenceMs: null, measuredFps: null,
    rawBytes: buffer.length, evidenceBytes: null, requestedBy: actor ? actor.email : null,
    published: false, publishedAt: null, publishedCounts: null, createdAt: new Date().toISOString(),
  });
  audit(actor, 'ANALYSIS_UPLOADED', 'ai_job', id, `${meta.filename} (${(buffer.length / 1024).toFixed(0)} KB, ${job.engine})`);
  await db.commit();

  if (process.env.VERCEL || process.env.DATABASE_URL) await runJob(id);
  else setImmediate(() => runJob(id).catch(err => console.error('[ai job]', id, err)));
  return { ok: true, job: db.get('ai_jobs', id) || job };
}

async function runJob(id) {
  let job = db.get('ai_jobs', id);
  if (!job) return;
  db.update('ai_jobs', id, { status: 'processing', startedAt: new Date().toISOString() });
  await db.commit();
  emit('job', { id, status: 'processing' });

  const outDir = path.join(EVIDENCE_DIR, id);
  fs.mkdirSync(outDir, { recursive: true });
  const r = await cv.analyze(job, outDir);
  if (!r.ok) {
    db.update('ai_jobs', id, { status: 'failed', error: r.error, finishedAt: new Date().toISOString() });
    await db.commit();
    emit('job', { id, status: 'failed', error: r.error });
    return;
  }

  const evidenceMap = new Map();
  if (storage.shouldUseBlob()) {
    for (const f of fs.readdirSync(outDir)) {
      const fp = path.join(outDir, f);
      if (!fs.statSync(fp).isFile()) continue;
      const ext = path.extname(f).toLowerCase();
      try {
        const saved = await storage.putFile(`evidence/${id}/${f}`, fp, mimeFor(ext));
        evidenceMap.set(f, saved.url);
      } catch (err) { console.warn('[ai] evidence persistence failed', f, err.message); }
    }
  }

  const evidenceUrl = f => {
    if (!f) return null;
    if (/^https?:\/\//i.test(f)) return f;
    return evidenceMap.get(f) || (process.env.VERCEL ? null : `/api/evidence/${id}/${f}`);
  };
  const results = (r.results || []).map((d, i) => ({
    idx: i, class: d.class, confidence: d.confidence,
    frameNumber: d.frame_number ?? null, frameTimeS: d.frame_time_s ?? null,
    bboxNorm: d.bbox_norm || null, bboxPx: d.bbox_px || null, features: d.features || null,
    evidenceImage: d.evidence_annotated ? evidenceUrl(d.evidence_annotated) : (d.evidence_url || null),
    evidenceCrop: d.evidence_crop ? evidenceUrl(d.evidence_crop) : null,
    latitude: Number.isFinite(d.latitude) ? d.latitude : job.latitude,
    longitude: Number.isFinite(d.longitude) ? d.longitude : job.longitude,
  }));
  job = db.update('ai_jobs', id, {
    status: 'complete', results, engine: r.engine || job.engine,
    framesProcessed: r.framesProcessed ?? null, avgInferenceMs: r.avgInferenceMs ?? null,
    measuredFps: r.measuredFps ?? null, evidenceBytes: dirBytes(outDir), finishedAt: new Date().toISOString(),
  });
  await db.commit();
  emit('job', { id, status: 'complete', detections: results.length });
}

function publish(jobId, actor) {
  const job = db.get('ai_jobs', jobId);
  if (!job) return { ok: false, code: 404, error: 'Job not found' };
  if (job.status !== 'complete') return { ok: false, code: 409, error: `Job is ${job.status}, not complete` };
  if (job.published) return { ok: true, idempotent: true, counts: job.publishedCounts };
  const missingGeo = (job.results || []).some(r => !Number.isFinite(r.latitude) || !Number.isFinite(r.longitude));
  if (missingGeo) return { ok: false, code: 400, error: 'No GPS on this job — set capture latitude/longitude before publishing (detections are never placed by guesswork).' };

  const created = []; let merged = 0, idem = 0;
  for (const r of job.results || []) {
    const res = ingest.ingestDetection({
      eventUuid: `${job.id}:${r.idx}`, class: r.class, confidence: r.confidence,
      latitude: r.latitude, longitude: r.longitude, bbox: r.bboxNorm, frameNumber: r.frameNumber,
      deviceId: job.deviceId, busId: job.busId, routeId: job.routeCode, jobId: job.id,
      modelName: job.engine, modelVersion: job.engine === 'classical-cv-v1' ? 'v1' : 'external',
      inferenceMs: job.avgInferenceMs, evidenceImage: r.evidenceImage, evidenceCrop: r.evidenceCrop,
      timestamp: job.createdAt, isDemo: !!job.isDemo,
    }, 'upload', actor);
    if (!res.ok) return { ok: false, code: res.code || 400, error: `Result ${r.idx}: ${res.error}` };
    if (res.idempotent) idem++; else { created.push({ ...r, category: r.class, id: res.detection.id }); if (res.merged) merged++; }
  }
  const cleared = verify.onScanCompleted(job, created);
  const counts = { published: created.length, mergedIntoExisting: merged, idempotentReplays: idem, verificationClears: cleared.length };
  db.update('ai_jobs', jobId, { published: true, publishedAt: new Date().toISOString(), publishedCounts: counts });
  audit(actor, 'ANALYSIS_PUBLISHED', 'ai_job', jobId, JSON.stringify(counts));
  emit('job', { id: jobId, status: 'published', counts });
  return { ok: true, counts };
}

async function generateTestFrame(meta, actor) {
  const script = `
import cv2, numpy as np, sys
rng = np.random.default_rng(42)
img = np.full((720,1280,3), 128, np.uint8)
img = np.clip(img.astype(np.int16)+rng.normal(0,14,(720,1280,1)).astype(np.int16),0,255).astype(np.uint8)
cv2.rectangle(img,(0,0),(1280,300),(190,182,172),-1)
for x in range(600,681,40): cv2.rectangle(img,(x,300),(x+18,720),(212,212,212),-1)
for cx,cy,ax,ay in [(430,540,80,45),(890,600,58,38)]:
    cv2.ellipse(img,(cx,cy),(ax,ay),0,0,360,(38,36,40),-1)
    cv2.ellipse(img,(cx,cy),(ax,ay),0,0,360,(72,68,72),5)
cv2.putText(img,'SYNTHETIC TEST FRAME - DEMO DATA',(24,40),cv2.FONT_HERSHEY_SIMPLEX,0.9,(30,30,200),2,cv2.LINE_AA)
cv2.imwrite(sys.argv[1],img)
print('ok')
`;
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
  const tmp = path.join(UPLOAD_DIR, `test_${Date.now()}.jpg`);
  const r = spawnSync('python3', ['-c', script, tmp], { timeout: 30000 });
  if (r.status !== 0 || !fs.existsSync(tmp)) return { ok: false, code: 500, error: 'Test-frame generator failed: ' + (r.stderr || '').toString().slice(-200) };
  const buf = fs.readFileSync(tmp); try { fs.unlinkSync(tmp); } catch {}
  return createJobFromUpload(buf, { ...meta, filename: `synthetic_test_${Date.now()}.jpg`, sourceKind: 'synthetic_test' }, actor);
}

module.exports = { createJobFromUpload, publish, generateTestFrame, bindEmitter, EVIDENCE_DIR, UPLOAD_DIR, runJob };
