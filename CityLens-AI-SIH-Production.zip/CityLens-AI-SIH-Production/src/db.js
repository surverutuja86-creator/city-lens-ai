'use strict';
/**
 * CityLens persistence layer.
 *
 * Local development: atomic JSON file under data/citylens.json.
 * Production / Vercel: Neon PostgreSQL when DATABASE_URL is present.
 *
 * The application historically used synchronous collection access throughout.
 * To preserve that proven domain logic while making persistence serverless-safe,
 * each request refreshes an in-memory snapshot from Neon, domain code mutates the
 * snapshot synchronously, and commit() durably writes the exact row mutations
 * before the HTTP response is returned. This avoids ephemeral filesystem state
 * without a risky rewrite of the incident/dedupe/SLA engines.
 */
const fs = require('fs');
const path = require('path');
const { AsyncLocalStorage } = require('async_hooks');

const DATA_DIR = process.env.CITYLENS_DATA_DIR ? path.resolve(process.env.CITYLENS_DATA_DIR) : path.join(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'citylens.json');
const TMP_FILE = DB_FILE + '.tmp';
const DATABASE_URL = process.env.DATABASE_URL || '';

const COLLECTIONS = [
  'users', 'buses', 'devices', 'routes', 'departments',
  'telemetry', 'detections', 'observations', 'ingest_events',
  'incidents', 'incident_history', 'tickets', 'ticket_history',
  'repair_evidence', 'verifications',
  'sla_rules', 'escalations', 'notifications', 'audit_logs', 'human_feedback',
  'safety_zones', 'road_segments',
  'ai_jobs', 'ai_models',
  'integrations', 'settings',
];
const SCHEMA_VERSION = 3;

let state = null;
let dirty = false;
let flushTimer = null;
let sql = null;
let neonReady = false;
let lastNeonError = null;
let pending = [];
let revisions = new Map();
let metaRevision = 0;
let initPromise = null;
const requestStore = new AsyncLocalStorage();

function requestCtx() { return DATABASE_URL ? requestStore.getStore() : null; }
function currentState() { const c = requestCtx(); return c && c.state ? c.state : state; }
function assignState(next) { const c = requestCtx(); if (c) c.state = next; else state = next; return next; }
function currentPending() { const c = requestCtx(); return c ? c.pending : pending; }
function currentRevisions() { const c = requestCtx(); return c ? c.revisions : revisions; }
function assignRevisions(next) { const c = requestCtx(); if (c) c.revisions = next; else revisions = next; return next; }
function currentMetaRevision() { const c = requestCtx(); return c ? c.metaRevision : metaRevision; }
function assignMetaRevision(next) { const c = requestCtx(); if (c) c.metaRevision = next; else metaRevision = next; return next; }
function revKey(collection, id) { return `${collection}\u0000${id}`; }

function emptyState() {
  const s = { _meta: { version: SCHEMA_VERSION, seededAt: null, backend: DATABASE_URL ? 'neon' : 'json' } };
  for (const c of COLLECTIONS) s[c] = [];
  return s;
}

function ensureCollection(coll) {
  if (!COLLECTIONS.includes(coll)) throw new Error(`Unknown collection: ${coll}`);
}

function loadLocal() {
  if (state) return state;
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (fs.existsSync(DB_FILE)) {
    try {
      state = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
      for (const c of COLLECTIONS) if (!Array.isArray(state[c])) state[c] = [];
      if (!state._meta) state._meta = { version: SCHEMA_VERSION, seededAt: null };
      state._meta.version = SCHEMA_VERSION;
      state._meta.backend = 'json';
    } catch (err) {
      console.error('[db] corrupt local data file, starting fresh:', err.message);
      state = emptyState();
    }
  } else state = emptyState();
  return state;
}

async function initNeon() {
  if (!DATABASE_URL) return;
  if (neonReady) return;
  try {
    const { neon } = require('@neondatabase/serverless');
    sql = neon(DATABASE_URL);
    await sql`CREATE TABLE IF NOT EXISTS citylens_documents (
      collection TEXT NOT NULL,
      id TEXT NOT NULL,
      data JSONB NOT NULL,
      revision BIGINT NOT NULL DEFAULT 1,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      PRIMARY KEY (collection, id)
    )`;
    await sql`ALTER TABLE citylens_documents ADD COLUMN IF NOT EXISTS revision BIGINT NOT NULL DEFAULT 1`;
    await sql`CREATE INDEX IF NOT EXISTS citylens_documents_collection_idx ON citylens_documents(collection)`;
    await sql`CREATE TABLE IF NOT EXISTS citylens_meta (
      key TEXT PRIMARY KEY,
      value JSONB NOT NULL,
      revision BIGINT NOT NULL DEFAULT 1,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
    )`;
    await sql`ALTER TABLE citylens_meta ADD COLUMN IF NOT EXISTS revision BIGINT NOT NULL DEFAULT 1`;
    await sql`CREATE OR REPLACE FUNCTION citylens_assert_mutation(ok BOOLEAN) RETURNS BOOLEAN AS $$
      BEGIN
        IF NOT ok THEN
          RAISE EXCEPTION 'CityLens concurrent update detected' USING ERRCODE = '40001';
        END IF;
        RETURN TRUE;
      END;
    $$ LANGUAGE plpgsql`;
    neonReady = true;
    lastNeonError = null;
  } catch (err) {
    lastNeonError = err;
    console.error('[db] Neon init failed:', err.message);
    throw err;
  }
}

async function refresh() {
  if (!DATABASE_URL) { loadLocal(); return state; }
  await initNeon();
  try {
    const next = emptyState();
    const [rows, metas] = await sql.transaction([
      sql`SELECT collection, id, data, revision FROM citylens_documents`,
      sql`SELECT key, value, revision FROM citylens_meta`,
    ]);
    const nextRevisions = new Map();
    for (const r of rows) {
      if (!COLLECTIONS.includes(r.collection)) continue;
      next[r.collection].push(typeof r.data === 'string' ? JSON.parse(r.data) : r.data);
      nextRevisions.set(revKey(r.collection, r.id), Number(r.revision) || 1);
    }
    const storedMeta = metas.find(r => r.key === 'state');
    if (storedMeta) next._meta = { ...next._meta, ...(typeof storedMeta.value === 'string' ? JSON.parse(storedMeta.value) : storedMeta.value), backend: 'neon', version: SCHEMA_VERSION };
    assignState(next);
    assignRevisions(nextRevisions);
    assignMetaRevision(storedMeta ? (Number(storedMeta.revision) || 1) : 0);
    neonReady = true;
    lastNeonError = null;
    return next;
  } catch (err) {
    lastNeonError = err;
    neonReady = false;
    throw err;
  }
}

async function init() {
  if (process.env.VERCEL && !DATABASE_URL) throw new Error('DATABASE_URL is required on Vercel. Connect Neon and configure the environment variable.');
  if (initPromise) return initPromise;
  initPromise = (async () => {
    if (DATABASE_URL) await refresh();
    else loadLocal();
    return currentState();
  })();
  return initPromise;
}

function load() {
  const active = currentState();
  if (!active) {
    if (DATABASE_URL) throw new Error('Database snapshot not initialised for this request. Call await db.refresh() first.');
    return loadLocal();
  }
  return active;
}

function flushNow() {
  if (DATABASE_URL) return; // Neon writes are handled by commit().
  if (!state) return;
  dirty = false;
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(TMP_FILE, JSON.stringify(state));
    fs.renameSync(TMP_FILE, DB_FILE);
  } catch (err) { console.error('[db] flush failed:', err.message); }
}

function persist(op) {
  if (DATABASE_URL) {
    if (op) currentPending().push(op);
    return;
  }
  dirty = true;
  if (flushTimer) return;
  flushTimer = setTimeout(() => { flushTimer = null; if (dirty) flushNow(); }, 250);
}

async function commit() {
  if (!DATABASE_URL) { if (dirty) flushNow(); return; }
  await initNeon();
  const target = currentPending();
  if (!target.length) return;
  const ops = target.splice(0, target.length);
  try {
    const queries = [];
    for (const op of ops) {
      if (op.kind === 'reset') {
        queries.push(sql`DELETE FROM citylens_documents`);
        queries.push(sql`DELETE FROM citylens_meta`);
      } else if (op.kind === 'upsert') {
        if ((op.expectedRevision || 0) === 0) {
          queries.push(sql`WITH changed AS (
            INSERT INTO citylens_documents (collection,id,data,revision,updated_at)
            VALUES (${op.collection},${op.row.id},${JSON.stringify(op.row)}::jsonb,1,now())
            ON CONFLICT (collection,id) DO NOTHING RETURNING 1
          ) SELECT citylens_assert_mutation(EXISTS(SELECT 1 FROM changed))`);
        } else {
          queries.push(sql`WITH changed AS (
            UPDATE citylens_documents SET data=${JSON.stringify(op.row)}::jsonb,revision=revision+1,updated_at=now()
            WHERE collection=${op.collection} AND id=${op.row.id} AND revision=${op.expectedRevision}
            RETURNING 1
          ) SELECT citylens_assert_mutation(EXISTS(SELECT 1 FROM changed))`);
        }
      } else if (op.kind === 'remove') {
        queries.push(sql`WITH changed AS (
          DELETE FROM citylens_documents
          WHERE collection=${op.collection} AND id=${op.id} AND revision=${op.expectedRevision}
          RETURNING 1
        ) SELECT citylens_assert_mutation(EXISTS(SELECT 1 FROM changed))`);
      } else if (op.kind === 'replaceAll') {
        queries.push(sql`DELETE FROM citylens_documents WHERE collection=${op.collection}`);
        for (const row of op.rows) {
          queries.push(sql`INSERT INTO citylens_documents (collection,id,data,revision,updated_at)
            VALUES (${op.collection},${row.id},${JSON.stringify(row)}::jsonb,1,now())`);
        }
      } else if (op.kind === 'meta') {
        if ((op.expectedRevision || 0) === 0) {
          queries.push(sql`WITH changed AS (
            INSERT INTO citylens_meta (key,value,revision,updated_at)
            VALUES ('state',${JSON.stringify(op.value)}::jsonb,1,now())
            ON CONFLICT (key) DO NOTHING RETURNING 1
          ) SELECT citylens_assert_mutation(EXISTS(SELECT 1 FROM changed))`);
        } else {
          queries.push(sql`WITH changed AS (
            UPDATE citylens_meta SET value=${JSON.stringify(op.value)}::jsonb,revision=revision+1,updated_at=now()
            WHERE key='state' AND revision=${op.expectedRevision} RETURNING 1
          ) SELECT citylens_assert_mutation(EXISTS(SELECT 1 FROM changed))`);
        }
      }
    }
    if (queries.length) await sql.transaction(queries);
    neonReady = true;
    lastNeonError = null;
  } catch (err) {
    currentPending().unshift(...ops); // do not silently lose writes
    neonReady = false;
    lastNeonError = err;
    throw err;
  }
}

function all(coll) { ensureCollection(coll); return load()[coll]; }
function find(coll, predicate) { const rows = all(coll); return predicate ? rows.filter(predicate) : rows.slice(); }
function get(coll, id) { return all(coll).find(r => r.id === id) || null; }
function getBy(coll, field, value) { return all(coll).find(r => r[field] === value) || null; }

function insert(coll, row) {
  ensureCollection(coll);
  if (!row || !row.id) throw new Error(`insert(${coll}) requires row.id`);
  load()[coll].push(row);
  const key = revKey(coll, row.id), revs = currentRevisions();
  const expectedRevision = revs.get(key) || 0; revs.set(key, expectedRevision + 1);
  persist({ kind: 'upsert', collection: coll, row: { ...row }, expectedRevision });
  return row;
}
function insertMany(coll, rows) {
  ensureCollection(coll);
  for (const row of rows) insert(coll, row);
  return rows;
}
function update(coll, id, patch) {
  const row = get(coll, id);
  if (!row) return null;
  Object.assign(row, patch);
  const key = revKey(coll, id), revs = currentRevisions();
  const expectedRevision = revs.get(key) || 0; revs.set(key, expectedRevision + 1);
  persist({ kind: 'upsert', collection: coll, row: { ...row }, expectedRevision });
  return row;
}
function remove(coll, id) {
  const rows = all(coll); const i = rows.findIndex(r => r.id === id);
  if (i === -1) return false;
  const key = revKey(coll, id), revs = currentRevisions();
  const expectedRevision = revs.get(key) || 0;
  rows.splice(i, 1); revs.delete(key); persist({ kind: 'remove', collection: coll, id, expectedRevision }); return true;
}
function replaceAll(coll, rows) {
  ensureCollection(coll); load()[coll] = rows;
  const revs = currentRevisions();
  for (const key of [...revs.keys()]) if (key.startsWith(`${coll}\u0000`)) revs.delete(key);
  for (const row of rows) revs.set(revKey(coll, row.id), 1);
  persist({ kind: 'replaceAll', collection: coll, rows: rows.map(r => ({ ...r })) });
}
function meta() { return load()._meta; }
function setMeta(patch) {
  Object.assign(load()._meta, patch, { version: SCHEMA_VERSION, backend: DATABASE_URL ? 'neon' : 'json' });
  const expectedRevision = currentMetaRevision(); assignMetaRevision(expectedRevision + 1);
  persist({ kind: 'meta', value: { ...load()._meta }, expectedRevision });
}
function count(coll, predicate) { const rows = all(coll); return predicate ? rows.reduce((n, r) => n + (predicate(r) ? 1 : 0), 0) : rows.length; }
function isSeeded() { return !!load()._meta.seededAt; }
function resetAll() {
  assignState(emptyState()); assignRevisions(new Map()); assignMetaRevision(0);
  const target = currentPending(); target.splice(0, target.length);
  persist({ kind: 'reset' });
}

function checkpoint() {
  const current = load();
  return {
    state: JSON.parse(JSON.stringify(current)),
    pendingLength: currentPending().length,
    revisions: new Map(currentRevisions()),
    metaRevision: currentMetaRevision(),
    dirty,
  };
}
function rollback(point) {
  if (!point) return;
  assignState(point.state); assignRevisions(new Map(point.revisions || [])); assignMetaRevision(point.metaRevision || 0);
  const target = currentPending(); target.splice(point.pendingLength);
  dirty = point.dirty;
}

function runRequest(fn) {
  if (!DATABASE_URL) return fn();
  return requestStore.run({ state: null, pending: [], revisions: new Map(), metaRevision: 0 }, fn);
}

function status() {
  return {
    backend: DATABASE_URL ? 'neon' : 'json-local',
    configured: !!DATABASE_URL,
    connected: DATABASE_URL ? neonReady : true,
    error: lastNeonError ? lastNeonError.message : null,
    collections: COLLECTIONS.length,
  };
}

process.on('exit', () => { if (!DATABASE_URL && dirty) flushNow(); });
process.on('SIGINT', () => { if (!DATABASE_URL && dirty) flushNow(); });
process.on('SIGTERM', () => { if (!DATABASE_URL && dirty) flushNow(); });

module.exports = {
  init, refresh, commit, load, all, find, get, getBy, insert, insertMany, update, remove,
  replaceAll, meta, setMeta, count, isSeeded, resetAll, flushNow, status, checkpoint, rollback, runRequest,
  DATA_DIR, COLLECTIONS,
};
