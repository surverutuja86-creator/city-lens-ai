'use strict';
/** Persistent evidence storage: private Vercel Blob in production, local dev files otherwise. */
const fs = require('fs');
const path = require('path');
const { Readable } = require('stream');
const { pipeline } = require('stream/promises');

const staticBlobConfigured = () => !!(process.env.BLOB_READ_WRITE_TOKEN || process.env.BLOB_STORE_ID);
// New Vercel projects can authenticate Blob with request-scoped OIDC and no long-lived token.
// On Vercel we therefore attempt the Blob SDK even when a static token is absent; the SDK
// returns a real configuration error if no Blob store is connected.
const shouldUseBlob = () => staticBlobConfigured() || !!process.env.VERCEL;
const blobAccess = () => (process.env.BLOB_ACCESS === 'public' ? 'public' : 'private');

async function putBuffer(key, buffer, contentType = 'application/octet-stream') {
  const safeKey = String(key).replace(/^\/+/, '').replace(/\.\./g, '_');
  if (shouldUseBlob()) {
    const { put } = require('@vercel/blob');
    const access = blobAccess();
    const opts = { access, addRandomSuffix: false, contentType };
    if (process.env.BLOB_READ_WRITE_TOKEN) opts.token = process.env.BLOB_READ_WRITE_TOKEN;
    const out = await put(`citylens/${safeKey}`, buffer, opts);
    const pathname = out.pathname || `citylens/${safeKey}`;
    return {
      backend: `vercel-blob-${access}`,
      pathname,
      directUrl: out.url,
      // Private blobs are never exposed directly. The authenticated API mints a
      // short-lived signed GET URL and redirects the browser.
      url: access === 'private' ? `/api/blob?key=${encodeURIComponent(pathname)}` : out.url,
    };
  }
  if (process.env.VERCEL) throw new Error('Persistent Blob storage is not connected. Configure a Vercel Blob store before uploading evidence.');
  const root = path.join(process.env.CITYLENS_DATA_DIR ? path.resolve(process.env.CITYLENS_DATA_DIR) : path.join(__dirname, '..', 'data'), 'objects');
  const fp = path.join(root, safeKey);
  fs.mkdirSync(path.dirname(fp), { recursive: true });
  fs.writeFileSync(fp, buffer);
  return { backend: 'local-development', url: `/api/object?key=${encodeURIComponent(safeKey)}`, path: fp, pathname: safeKey };
}

async function putFile(key, filePath, contentType = 'application/octet-stream') {
  return putBuffer(key, fs.readFileSync(filePath), contentType);
}

async function signedGetUrl(pathname) {
  if (!shouldUseBlob()) throw new Error('Vercel Blob is not configured');
  const { issueSignedToken, presignUrl } = require('@vercel/blob');
  const validUntil = Date.now() + 5 * 60 * 1000;
  const issueOpts = { pathname, operations: ['get'], validUntil };
  if (process.env.BLOB_READ_WRITE_TOKEN) issueOpts.token = process.env.BLOB_READ_WRITE_TOKEN;
  const token = await issueSignedToken(issueOpts);
  const { presignedUrl } = await presignUrl(token, { pathname, operation: 'get', validUntil, useCache: true });
  return presignedUrl;
}

async function signedPutUrl(pathname, contentType, maximumSizeInBytes) {
  if (!shouldUseBlob()) throw new Error('Vercel Blob is not configured');
  const { issueSignedToken, presignUrl } = require('@vercel/blob');
  const validUntil = Date.now() + 15 * 60 * 1000;
  const issueOpts = {
    pathname,
    operations: ['put'],
    allowedContentTypes: [contentType || 'application/octet-stream'],
    maximumSizeInBytes,
    validUntil,
  };
  if (process.env.BLOB_READ_WRITE_TOKEN) issueOpts.token = process.env.BLOB_READ_WRITE_TOKEN;
  const token = await issueSignedToken(issueOpts);
  const { presignedUrl } = await presignUrl(token, { pathname, operation: 'put', validUntil });
  return { presignedUrl, validUntil };
}

async function headObject(pathname) {
  if (!shouldUseBlob()) throw new Error('Vercel Blob is not configured');
  const { head } = require('@vercel/blob');
  const opts = {};
  if (process.env.BLOB_READ_WRITE_TOKEN) opts.token = process.env.BLOB_READ_WRITE_TOKEN;
  return head(pathname, opts);
}

async function downloadToFile(pathname, destination) {
  if (!shouldUseBlob()) throw new Error('Vercel Blob is not configured');
  const { get } = require('@vercel/blob');
  const opts = { access: blobAccess(), useCache: false };
  if (process.env.BLOB_READ_WRITE_TOKEN) opts.token = process.env.BLOB_READ_WRITE_TOKEN;
  const result = await get(pathname, opts);
  if (!result || result.statusCode !== 200 || !result.stream) throw new Error('Blob source not found');
  fs.mkdirSync(path.dirname(destination), { recursive: true });
  await pipeline(Readable.fromWeb(result.stream), fs.createWriteStream(destination, { flags: 'wx' }));
  return result.blob;
}

function status() {
  const staticConfigured = staticBlobConfigured();
  const oidcRuntime = !!process.env.VERCEL && !process.env.BLOB_READ_WRITE_TOKEN;
  return {
    backend: shouldUseBlob() ? `vercel-blob-${blobAccess()}` : 'local-development',
    // true = explicit static/store configuration is visible; null = Vercel runtime will
    // resolve a connected OIDC Blob store on first operation; false = local dev fallback.
    configured: staticConfigured ? true : (process.env.VERCEL ? null : false),
    runtimeAuth: process.env.BLOB_READ_WRITE_TOKEN ? 'token' : (process.env.VERCEL ? 'oidc' : 'local'),
    oidcRuntime,
    access: shouldUseBlob() ? blobAccess() : null,
  };
}

module.exports = { putBuffer, putFile, signedGetUrl, signedPutUrl, headObject, downloadToFile, status, blobConfigured: staticBlobConfigured, shouldUseBlob, blobAccess };
