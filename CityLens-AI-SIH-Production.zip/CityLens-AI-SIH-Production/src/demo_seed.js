'use strict';
require('./env');
/**
 * Optional SIH demonstration dataset. Every operational record is visibly marked
 * isDemo=true / datasetLabel='Demo Dataset'. Never runs automatically.
 */
const db = require('./db');
const storage = require('./storage');
const { seed } = require('./seed');
const { uid } = require('./util');

const iso = ms => new Date(ms).toISOString();
const DEMO = { isDemo: true, datasetLabel: 'Demo Dataset' };

async function seedDemo({ force = false } = {}) {
  await db.init();
  seed();
  await db.commit();

  const existing = db.find('incidents', x => x.isDemo);
  if (existing.length && !force) {
    console.log(`[demo] already present (${existing.length} incident). Use DEMO_FORCE=1 to replace.`);
    return false;
  }
  if (force) {
    for (const coll of ['telemetry','detections','observations','ingest_events','incidents','incident_history','tickets','ticket_history','repair_evidence','verifications','notifications','human_feedback','audit_logs']) {
      db.replaceAll(coll, db.all(coll).filter(x => !x.isDemo));
    }
  }

  const now = Date.now();
  const route = db.all('routes')[0];
  const buses = db.all('buses').slice(0, 2);
  const devices = db.all('devices').filter(d => d.busId).slice(0, 2);
  const field = db.getBy('users', 'email', 'field@citylens.ai');
  const operator = db.getBy('users', 'email', 'operator@citylens.ai');
  const lat = 18.51618, lng = 73.85672;

  const incidentId = uid('INC');
  const ticketId = uid('TKT');
  const d1 = uid('DET'), d2 = uid('DET');
  const t1 = iso(now - 4.5 * 3600e3), t2 = iso(now - 4.1 * 3600e3);

  db.insert('telemetry', { id: uid('TEL'), eventUuid: `demo-tel-1-${incidentId}`, busId: buses[0]?.id, deviceId: devices[0]?.id, routeId: route?.id, latitude: lat, longitude: lng, speed: 28, heading: 96, accuracyM: 6, source: 'edge', timestamp: t1, receivedAt: t1, ...DEMO });
  db.insert('telemetry', { id: uid('TEL'), eventUuid: `demo-tel-2-${incidentId}`, busId: buses[1]?.id, deviceId: devices[1]?.id, routeId: route?.id, latitude: lat + .00004, longitude: lng - .00003, speed: 24, heading: 94, accuracyM: 5, source: 'edge', timestamp: t2, receivedAt: t2, ...DEMO });

  const detections = [
    { id:d1, eventUuid:`demo-det-1-${incidentId}`, deviceId:devices[0]?.id,busId:buses[0]?.id,confidence:.91,latitude:lat,longitude:lng,timestamp:t1,createdAt:t1 },
    { id:d2, eventUuid:`demo-det-2-${incidentId}`, deviceId:devices[1]?.id,busId:buses[1]?.id,confidence:.88,latitude:lat+.00004,longitude:lng-.00003,timestamp:t2,createdAt:t2 },
  ];
  for (const d of detections) db.insert('detections', { ...d, sourceType:'demo_seed', sourceId:'sih-demo', routeId:route?.id, jobId:null, category:'pothole', boundingBox:[.38,.58,.61,.82], frameNumber:42, locationName:'Demo Corridor · Central Pune', evidenceImage:null, evidenceCrop:null, modelName:'demo-labelled-observation', modelVersion:'1', inferenceMs:31, privacyStatus:'demo', validationState:'CORRECT', incidentId, ...DEMO });

  db.insert('incidents', { id:incidentId, code:'INC-DEMO-001', category:'pothole', status:'CLOSED', latitude:lat, longitude:lng, locationName:'Demo Corridor · Central Pune', routeId:route?.id, department:'Road Maintenance', ticketId, firstSeenAt:t1, lastSeenAt:t2, observationCount:2, uniqueDeviceCount:2, uniqueBusCount:2, aggConfidence:.9892, maxConfidence:.91, aggMethod:'noisy-OR across independent demo observations', impactScore:82, impactBreakdown:{confidence:27,safety:18,repeat:14,roadImportance:11,urgency:12}, repairSubmittedAt:iso(now-2*3600e3), verifiedAt:iso(now-45*60e3), closedAt:iso(now-40*60e3), createdAt:t1, updatedAt:iso(now-40*60e3), ...DEMO });
  db.insert('observations', { id:uid('OBS'), incidentId, detectionId:d1, deviceId:devices[0]?.id,busId:buses[0]?.id,sourceType:'demo_seed',confidence:.91,latitude:lat,longitude:lng,distanceFromIncidentM:0,timestamp:t1,...DEMO });
  db.insert('observations', { id:uid('OBS'), incidentId, detectionId:d2, deviceId:devices[1]?.id,busId:buses[1]?.id,sourceType:'demo_seed',confidence:.88,latitude:lat+.00004,longitude:lng-.00003,distanceFromIncidentM:6,timestamp:t2,...DEMO });

  const ih = [
    [null,'DETECTED',t1,'First bus observation opened incident'],
    ['DETECTED','UNDER_REVIEW',iso(now-3.9*3600e3),'Second independent bus confirmed repeat observation'],
    ['UNDER_REVIEW','CONFIRMED',iso(now-3.6*3600e3),'Operator confirmed demo incident'],
    ['CONFIRMED','ASSIGNED',iso(now-3.4*3600e3),'Routed to Road Maintenance with SLA ticket'],
    ['ASSIGNED','IN_PROGRESS',iso(now-2.8*3600e3),'Field worker started repair'],
    ['IN_PROGRESS','REPAIR_SUBMITTED',iso(now-2*3600e3),'After-repair evidence submitted'],
    ['REPAIR_SUBMITTED','AWAITING_VERIFICATION',iso(now-1.9*3600e3),'Awaiting post-repair re-scan'],
    ['AWAITING_VERIFICATION','VERIFIED',iso(now-45*60e3),'Clear re-scan verified repair'],
    ['VERIFIED','CLOSED',iso(now-40*60e3),'Closed loop complete'],
  ];
  for (const [previousStatus,newStatus,timestamp,note] of ih) db.insert('incident_history',{id:uid('IH'),incidentId,previousStatus,newStatus,changedBy:newStatus==='VERIFIED'?'system':operator?.email||'demo',role:newStatus==='VERIFIED'?'system':'operator',note,ticketId,metadata:{demo:true},timestamp,...DEMO});

  const dueAt = iso(now + 7.5*3600e3);
  db.insert('tickets',{id:ticketId,code:'TKT-DEMO-001',incidentId,incidentCode:'INC-DEMO-001',category:'pothole',department:'Road Maintenance',priority:'CRITICAL',impactScore:82,status:'CLOSED',assignedOfficerId:field?.id||null,notes:'SIH demo closed-loop repair',slaRuleId:null,slaRuleName:'Critical pothole',slaHours:12,dueAt,slaStatus:'RESOLVED_WITHIN_SLA',escalationLevel:0,workStartedAt:iso(now-2.8*3600e3),repairSubmittedAt:iso(now-2*3600e3),resolvedAt:iso(now-40*60e3),createdBy:operator?.email||'demo',createdAt:iso(now-3.4*3600e3),updatedAt:iso(now-40*60e3),...DEMO});
  const th = [
    [null,'OPEN',iso(now-3.4*3600e3),'Ticket created from confirmed incident'],
    ['OPEN','ASSIGNED',iso(now-3.2*3600e3),'Assigned to field worker'],
    ['ASSIGNED','ACKNOWLEDGED',iso(now-3*3600e3),'Field worker acknowledged'],
    ['ACKNOWLEDGED','WORK_STARTED',iso(now-2.8*3600e3),'Repair work started'],
    ['WORK_STARTED','REPAIR_SUBMITTED',iso(now-2*3600e3),'Repair evidence uploaded'],
    ['REPAIR_SUBMITTED','AWAITING_VERIFICATION',iso(now-1.9*3600e3),'Awaiting scanner verification'],
    ['AWAITING_VERIFICATION','RESOLVED',iso(now-45*60e3),'AI re-observation clear'],
    ['RESOLVED','CLOSED',iso(now-40*60e3),'Ticket closed within SLA'],
  ];
  for (const [previousStatus,newStatus,timestamp,note] of th) db.insert('ticket_history',{id:uid('TH'),ticketId,previousStatus,newStatus,changedBy:newStatus==='RESOLVED'?'system':field?.email||'demo',role:newStatus==='RESOLVED'?'system':'field',note,metadata:{demo:true},timestamp,...DEMO});

  // Purpose-built demo evidence; never represented as live municipal imagery.
  const makeSvg = (label, repaired) => Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" width="960" height="540"><rect width="100%" height="100%" fill="${repaired?'#25352e':'#292b31'}"/><rect y="170" width="960" height="370" fill="#4b4d52"/><path d="M480 180v350" stroke="#e9e6d8" stroke-width="12" stroke-dasharray="45 28"/>${repaired?'':`<ellipse cx="650" cy="390" rx="105" ry="48" fill="#17181b" stroke="#0c0d0f" stroke-width="12"/>`}<text x="42" y="70" fill="#fff" font-family="sans-serif" font-size="34">DEMO DATA · ${label}</text><text x="42" y="112" fill="#c8ccd4" font-family="sans-serif" font-size="20">Illustrative SIH workflow evidence — not live municipal imagery</text></svg>`);
  let beforeUrl=null, afterUrl=null, backend='embedded-demo';
  try {
    const before=await storage.putBuffer(`demo/${incidentId}/before.svg`,makeSvg('BEFORE REPAIR',false),'image/svg+xml');
    const after=await storage.putBuffer(`demo/${incidentId}/after.svg`,makeSvg('AFTER REPAIR',true),'image/svg+xml');
    beforeUrl=before.url; afterUrl=after.url; backend=before.backend;
  } catch (e) { console.warn('[demo] evidence storage skipped:',e.message); }
  if (beforeUrl) db.insert('repair_evidence',{id:uid('REV'),ticketId,incidentId,kind:'before',file:beforeUrl,storageBackend:backend,note:'Demo before-repair illustration',uploadedBy:field?.email||'demo',sizeBytes:null,timestamp:iso(now-2.9*3600e3),...DEMO});
  if (afterUrl) db.insert('repair_evidence',{id:uid('REV'),ticketId,incidentId,kind:'after',file:afterUrl,storageBackend:backend,note:'Demo after-repair illustration',uploadedBy:field?.email||'demo',sizeBytes:null,timestamp:iso(now-2*3600e3),...DEMO});

  db.insert('verifications',{id:uid('VER'),incidentId,result:'CLEAR',deviceId:devices[0]?.id,busId:buses[0]?.id,jobId:null,confidence:.94,threshold:.55,latitude:lat,longitude:lng,evidenceRef:null,timestamp:iso(now-45*60e3),...DEMO});
  db.insert('notifications',{id:uid('NTF'),kind:'DEMO_CLOSED_LOOP',severity:'low',title:'Demo incident closed — INC-DEMO-001',message:'Repair re-verified by a post-repair scan. Demo Dataset.',entityType:'incident',entityId:incidentId,forRole:'operator',forUserId:null,department:'Road Maintenance',isRead:false,archived:false,createdAt:iso(now-40*60e3),...DEMO});
  db.setMeta({ demoSeededAt:new Date().toISOString(), demoDatasetVersion:1 });
  await db.commit();
  console.log('[demo] seeded one coherent, explicitly labelled closed-loop SIH demonstration story.');
  return true;
}

if (require.main === module) seedDemo({ force: process.env.DEMO_FORCE === '1' }).catch(e=>{console.error(e);process.exit(1)});
module.exports = { seedDemo };
