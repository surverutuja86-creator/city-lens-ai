'use strict';
/** Minimal local env loader. Vercel/system environment values always win. */
const fs = require('fs');
const path = require('path');
let loaded = false;

function loadEnv() {
  if (loaded) return;
  loaded = true;
  const root = path.join(__dirname, '..');
  // .env.local overrides .env when the key is not already provided by the OS.
  for (const name of ['.env.local', '.env']) {
    const fp = path.join(root, name);
    let text = '';
    try { text = fs.readFileSync(fp, 'utf8'); } catch { continue; }
    for (const line of text.split(/\r?\n/)) {
      if (!line || /^\s*#/.test(line)) continue;
      const m = line.match(/^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!m || process.env[m[1]] !== undefined) continue;
      let value = m[2].trim();
      if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
      process.env[m[1]] = value;
    }
  }
}

loadEnv();
module.exports = { loadEnv };
