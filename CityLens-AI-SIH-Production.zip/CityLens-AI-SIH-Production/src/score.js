'use strict';
/**
 * Civic Impact Score (0–100). Every factor is computed from stored records;
 * weights live in settings.scoringWeights and are editable by admins.
 * The full breakdown is persisted on the incident so the number is explainable.
 */
const db = require('./db');
const geo = require('./geo');

const DEFAULT_WEIGHTS = {
  severity: 25,          // from category base + detection confidence
  trafficExposure: 18,   // telemetry points within 150 m in last 24 h (real fleet exposure)
  observations: 16,      // independent observation volume + unique devices
  zoneProximity: 15,     // school / hospital / footfall zones (safety_zones table)
  age: 10,               // unresolved time
  confidence: 8,         // aggregated incident confidence
  recurrence: 8,         // previously closed incidents of same class nearby
};

const CATEGORY_BASE = { // relative hazard of the defect class itself (0–1)
  accident: 1.0, waterlogging: 0.9, pothole: 0.85, obstruction: 0.8, road_damage: 0.7,
  missing_divider: 0.7, damaged_divider: 0.6, pedestrian_risk: 0.85, missing_zebra: 0.55,
  sign_damage: 0.5, road_crack: 0.45, congestion: 0.5, vehicle: 0.2, other: 0.35,
};

function setting(key) { const r = db.getBy('settings', 'key', key); return r ? r.value : undefined; }
function weights() { return { ...DEFAULT_WEIGHTS, ...(setting('scoringWeights') || {}) }; }

/** Compute score + breakdown for an incident row. Pure read — caller persists. */
function computeImpact(inc) {
  const W = weights();
  const now = Date.now();
  const parts = [];
  const add = (key, label, frac, note) => {
    const pts = Math.round(Math.max(0, Math.min(1, frac)) * W[key] * 10) / 10;
    parts.push({ key, label, points: pts, max: W[key], note });
    return pts;
  };

  // severity: category hazard scaled by best single-detection confidence
  const bestConf = Math.max(0.4, inc.maxConfidence || inc.aggConfidence || 0.5);
  const sevFrac = (CATEGORY_BASE[inc.category] ?? 0.35) * (0.6 + 0.4 * bestConf);
  add('severity', 'Severity', sevFrac, `${inc.category} · best conf ${(bestConf * 100).toFixed(0)}%`);

  // traffic exposure: real telemetry density near the point, last 24 h, saturates at 120 pings
  const since = new Date(now - 24 * 3600e3).toISOString();
  const nearPings = db.count('telemetry', t => t.timestamp >= since &&
    geo.haversineM(t.latitude, t.longitude, inc.latitude, inc.longitude) <= 150);
  add('trafficExposure', 'Traffic exposure', nearPings / 120, `${nearPings} fleet pings ≤150 m / 24 h`);

  // observations: volume + independence
  const obsN = inc.observationCount || 1, devN = inc.uniqueDeviceCount || 1;
  add('observations', 'Repeat observations', Math.min(1, (obsN - 1) / 6) * 0.6 + Math.min(1, (devN - 1) / 3) * 0.4,
    `${obsN} observations · ${devN} independent device(s)`);

  // zone proximity: strongest active zone whose radius covers the point (weight from zone config)
  const zones = geo.within(db.find('safety_zones', z => z.active), inc.latitude, inc.longitude, 100000)
    .filter(z => z.distanceM <= z.radiusM);
  const zTop = zones.sort((a, b) => (b.priorityWeight || 1) - (a.priorityWeight || 1))[0];
  add('zoneProximity', 'Safety-zone proximity', zTop ? Math.min(1, (zTop.priorityWeight || 1) / 3) : 0,
    zTop ? `${zTop.zoneType}: ${zTop.name} (${zTop.distanceM} m)` : 'no active zone covers this point');

  // age: hours unresolved, saturates at 96 h
  const ageH = (now - new Date(inc.firstSeenAt || inc.createdAt).getTime()) / 3600e3;
  add('age', 'Issue age', ageH / 96, `${ageH.toFixed(1)} h unresolved`);

  // aggregated confidence
  add('confidence', 'Detection confidence', (inc.aggConfidence || 0.5 - 0.4) / 0.6, `aggregated ${(100 * (inc.aggConfidence || 0)).toFixed(1)}%`);

  // recurrence: previously CLOSED incidents, same category, ≤40 m
  const rec = db.count('incidents', i => i.id !== inc.id && i.category === inc.category &&
    ['CLOSED', 'VERIFIED'].includes(i.status) &&
    geo.haversineM(i.latitude, i.longitude, inc.latitude, inc.longitude) <= 40);
  add('recurrence', 'Recurring location', Math.min(1, rec / 2), `${rec} prior closed incident(s) ≤40 m`);

  const score = Math.min(100, Math.round(parts.reduce((a, p) => a + p.points, 0)));
  return { score, breakdown: parts, weightsVersion: 'impact-v2', computedAt: new Date().toISOString() };
}

/** Recompute + persist impact for an incident id. */
function refreshImpact(incidentId) {
  const inc = db.get('incidents', incidentId);
  if (!inc) return null;
  const r = computeImpact(inc);
  return db.update('incidents', incidentId, { impactScore: r.score, impactBreakdown: r.breakdown, impactMeta: { weightsVersion: r.weightsVersion, computedAt: r.computedAt } });
}

module.exports = { computeImpact, refreshImpact, DEFAULT_WEIGHTS, CATEGORY_BASE };
