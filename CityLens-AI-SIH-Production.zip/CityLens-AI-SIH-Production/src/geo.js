'use strict';
/** Real geospatial math — used by dedupe, scoring, coverage, verification. */
const R = 6371000; // earth radius, metres

function toRad(d) { return d * Math.PI / 180; }

/** Great-circle distance in metres between two lat/lng points (Haversine). */
function haversineM(lat1, lng1, lat2, lng2) {
  const dLat = toRad(lat2 - lat1), dLng = toRad(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(a)));
}

/** Distance in metres from point P to segment AB (equirectangular approx — fine at city scale). */
function pointToSegmentM(plat, plng, alat, alng, blat, blng) {
  const latR = toRad((alat + blat) / 2);
  const x = l => toRad(l) * Math.cos(latR) * R, y = l => toRad(l) * R;
  const px = x(plng), py = y(plat), ax = x(alng), ay = y(alat), bx = x(blng), by = y(blat);
  const dx = bx - ax, dy = by - ay;
  const len2 = dx * dx + dy * dy;
  let t = len2 === 0 ? 0 : ((px - ax) * dx + (py - ay) * dy) / len2;
  t = Math.max(0, Math.min(1, t));
  const cx = ax + t * dx, cy = ay + t * dy;
  return Math.hypot(px - cx, py - cy);
}

/** All items within radiusM of (lat,lng); items need latitude/longitude. Adds distanceM. */
function within(items, lat, lng, radiusM) {
  const out = [];
  for (const it of items) {
    if (typeof it.latitude !== 'number' || typeof it.longitude !== 'number') continue;
    const d = haversineM(lat, lng, it.latitude, it.longitude);
    if (d <= radiusM) out.push({ ...it, distanceM: Math.round(d) });
  }
  return out.sort((a, b) => a.distanceM - b.distanceM);
}

/** Nearest road segment (from road_segments rows with a,b endpoints). */
function nearestSegment(segments, lat, lng, maxM = 120) {
  let best = null, bestD = Infinity;
  for (const s of segments) {
    const d = pointToSegmentM(lat, lng, s.a[0], s.a[1], s.b[0], s.b[1]);
    if (d < bestD) { bestD = d; best = s; }
  }
  return best && bestD <= maxM ? { segment: best, distanceM: Math.round(bestD) } : null;
}

module.exports = { haversineM, pointToSegmentM, within, nearestSegment };
