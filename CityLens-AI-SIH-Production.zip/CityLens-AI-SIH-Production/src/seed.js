'use strict';
require('./env');
/**
 * Seed v2 — CONFIGURATION ONLY.
 * v1 generated ~2,000 synthetic detections, incidents and analytics; that
 * violates the real-data rule and now lives in legacy/seed.v1.js. This seed
 * creates only what a real deployment configures up-front: accounts,
 * departments, route geometry, the fleet/device registry, safety zones, SLA
 * rules, integration placeholders and settings. Every operational collection
 * starts EMPTY and fills exclusively through real ingestion and user actions.
 */
const db = require('./db');
const { hashPassword } = require('./auth');
const { ROUTE_DEFS } = require('./catalog');
const { uid } = require('./util');
const geo = require('./geo');

const now = () => new Date().toISOString();

function isProduction() { return process.env.NODE_ENV === 'production' || !!process.env.VERCEL; }
function ensureProductionBootstrapAdmin() {
  if (!isProduction()) return false;
  const email = String(process.env.BOOTSTRAP_ADMIN_EMAIL || '').trim().toLowerCase();
  const pw = String(process.env.BOOTSTRAP_ADMIN_PASSWORD || '');
  if (!email || !pw) return false;
  if (pw.length < 12 || !/[A-Z]/.test(pw) || !/[a-z]/.test(pw) || !/[0-9]/.test(pw))
    throw new Error('BOOTSTRAP_ADMIN_PASSWORD must be 12+ chars with upper/lowercase and a number.');
  const existing = db.getBy('users', 'email', email);
  if (existing) {
    if (existing.role !== 'admin') console.warn('[seed] BOOTSTRAP_ADMIN_EMAIL already belongs to a non-admin account; automatic privilege elevation is intentionally refused.');
    return false;
  }
  db.insert('users', { id: uid('USR'), name: process.env.BOOTSTRAP_ADMIN_NAME || 'CityLens Admin', email,
    passwordHash: hashPassword(pw), role: 'admin', department: 'System Administration', sessionVersion: 1,
    bootstrapAccount: true, createdAt: now() });
  console.log('[seed] production bootstrap admin created from environment.');
  return true;
}
function seedUsers() {
  if (isProduction()) {
    if (!ensureProductionBootstrapAdmin())
      console.warn('[seed] production: no known-password demo accounts are created. Configure BOOTSTRAP_ADMIN_EMAIL/PASSWORD if an initial admin is still needed.');
    return;
  }
  const rows = [
    ['System Admin', 'admin@citylens.ai', 'admin123', 'admin', 'System Administration'],
    ['Rohit Kulkarni', 'operator@citylens.ai', 'operator123', 'operator', 'Municipal Command Centre'],
    ['Sneha Patil', 'roads@citylens.ai', 'officer123', 'officer', 'Road Maintenance'],
    ['Imran Shaikh', 'drainage@citylens.ai', 'officer123', 'officer', 'Drainage'],
    ['Vikram More', 'field@citylens.ai', 'field123', 'field', 'Road Maintenance'],
    ['Dr. Kavita Rao', 'reviewer@citylens.ai', 'review123', 'reviewer', 'Municipal Command Centre'],
    ['Ananya Iyer', 'analyst@citylens.ai', 'analyst123', 'analyst', 'Municipal Command Centre'],
  ];
  for (const [name, email, pw, role, department] of rows)
    db.insert('users', { id: uid('USR'), name, email, passwordHash: hashPassword(pw), role, department, sessionVersion: 1, demoAccount: true, createdAt: now() });
}

function seedDepartments() {
  for (const name of ['Road Maintenance', 'Traffic Operations', 'Drainage', 'Sanitation', 'Municipal Command Centre', 'System Administration'])
    db.insert('departments', { id: uid('DEP'), name, createdAt: now() });
}

function seedRoutes() {
  for (const [routeCode, routeName, startPoint, endPoint, waypoints] of ROUTE_DEFS) {
    let m = 0;
    for (let i = 0; i < waypoints.length - 1; i++)
      m += geo.haversineM(waypoints[i][0], waypoints[i][1], waypoints[i + 1][0], waypoints[i + 1][1]);
    db.insert('routes', { id: uid('RT'), routeCode, routeName, startPoint, endPoint,
      distanceKm: Math.round(m / 100) / 10, waypoints, importance: 'arterial', createdAt: now() });
  }
}

function seedFleet() {
  const routes = db.all('routes');
  for (let i = 1; i <= 12; i++) {
    const bus = db.insert('buses', {
      id: uid('BUS'), busCode: `BUS-${String(i).padStart(3, '0')}`, registrationNumber: `MH-12-${2400 + i}`,
      routeId: routes[(i - 1) % routes.length].id,
      status: 'no_telemetry',                       // honest: nothing has reported yet
      latitude: null, longitude: null, speed: null, heading: null,
      lastTelemetryAt: null, telemetrySource: null, active: true, createdAt: now(),
    });
    db.insert('devices', {
      id: uid('DEV'), deviceCode: `EDGE-${String(i).padStart(3, '0')}`, busId: bus.id,
      cameraStatus: 'unknown', gpsStatus: 'unknown', aiUnitStatus: 'unknown',
      connectionStatus: 'never_connected', lastHeartbeatAt: null,
      softwareVersion: null, modelVersion: null, active: true, createdAt: now(),
    });
  }
  db.insert('devices', { id: uid('DEV'), deviceCode: 'EDGE-FLD-01', busId: null, kind: 'field_tablet',
    cameraStatus: 'unknown', gpsStatus: 'unknown', aiUnitStatus: 'browser',
    connectionStatus: 'never_connected', lastHeartbeatAt: null, active: true, createdAt: now() });
}

function seedZones() {
  const zones = [
    ['Abhinav Vidyalaya', 18.5099, 73.8283, 220, 'SCHOOL', 3],
    ['Symbiosis School', 18.5286, 73.8365, 220, 'SCHOOL', 3],
    ['Sassoon General Hospital', 18.5262, 73.8683, 300, 'HOSPITAL', 3],
    ['Deenanath Mangeshkar Hospital', 18.5015, 73.8296, 300, 'HOSPITAL', 3],
    ['Swargate Bus Terminal', 18.5018, 73.8636, 260, 'HIGH_FOOTFALL', 2],
    ['Pune Railway Station', 18.5286, 73.8740, 300, 'HIGH_FOOTFALL', 2],
    ['Laxmi Road Market', 18.5158, 73.8535, 240, 'PEDESTRIAN_PRIORITY', 2],
    ['PMC Water Works', 18.5125, 73.8455, 180, 'CRITICAL_INFRASTRUCTURE', 2],
  ];
  for (const [name, latitude, longitude, radiusM, zoneType, priorityWeight] of zones)
    db.insert('safety_zones', { id: uid('ZON'), name, latitude, longitude, radiusM, zoneType, priorityWeight, active: true, source: 'seed-config', createdAt: now() });
}

function seedSla() {
  const rules = [
    ['Critical waterlogging', 'waterlogging', 70, 2],
    ['Waterlogging', 'waterlogging', 0, 24],
    ['Major obstruction', 'obstruction', 60, 1],
    ['Road accident', 'accident', 0, 2],
    ['Critical pothole', 'pothole', 75, 12],
    ['High pothole', 'pothole', 50, 24],
    ['Default road issue', '*', 0, 72],
  ];
  for (const [name, category, minImpact, hours] of rules)
    db.insert('sla_rules', { id: uid('SLA'), name, category, minImpact, hours, active: true, createdAt: now() });
}

function seedIntegrations() {
  const rows = [
    ['municipal_ticket_api', 'Municipal Ticket API (PMC)', 'Push confirmed tickets into the city grievance system.'],
    ['traffic_management_api', 'Traffic Management API', 'Share congestion/obstruction events with signal control.'],
    ['sms_gateway', 'SMS Gateway', 'Field-worker and escalation SMS.'],
    ['email_smtp', 'Email (SMTP)', 'Email notifications and report delivery.'],
    ['object_storage', 'Object Storage (S3-compatible)', 'Off-box evidence archival.'],
    ['gis_provider', 'GIS Provider', 'Authoritative basemap / geocoding.'],
  ];
  for (const [key, name, description] of rows)
    db.insert('integrations', { id: uid('ITG'), key, name, description, status: 'not_configured', enabled: false, config: {}, lastTestAt: null, lastTestResult: null, createdAt: now() });
}

function seedSettings() {
  const put = (key, value) => db.insert('settings', { id: uid('SET'), key, value, updatedAt: now() });
  put('city', 'Pune');
  put('categoryDepartmentMap', {
    pothole: 'Road Maintenance', road_crack: 'Road Maintenance', road_damage: 'Road Maintenance',
    sign_damage: 'Road Maintenance', missing_divider: 'Road Maintenance', damaged_divider: 'Road Maintenance',
    waterlogging: 'Drainage',
    obstruction: 'Traffic Operations', congestion: 'Traffic Operations', accident: 'Traffic Operations',
    missing_zebra: 'Traffic Operations', pedestrian_risk: 'Traffic Operations',
    vehicle: 'Traffic Operations', rash_driving: 'Traffic Operations', road_hazard: 'Traffic Operations',
    missing_sign: 'Road Maintenance', garbage_overflow: 'Sanitation', other: 'Municipal Command Centre',
  });
  put('mergeRadii', {});
  put('scoringWeights', {});
  put('verification', { minClearObservations: 3, minIndependentDevices: 2, confidenceThreshold: 0.55 });
}

function seed({ force = false } = {}) {
  if (db.isSeeded() && !force) {
    // Allows a production deployment that was initially configured without a
    // bootstrap admin to add one later, without resetting any existing data.
    ensureProductionBootstrapAdmin();
    return false;
  }
  db.resetAll();
  console.log('[seed] v2 — configuration only (no synthetic operational data)…');
  seedUsers(); seedDepartments(); seedRoutes(); seedFleet(); seedZones(); seedSla(); seedIntegrations(); seedSettings();
  require('./coverage').ensureSegments();
  db.setMeta({ seededAt: now(), seedVersion: 2 });
  db.flushNow();
  console.log(`[seed] done — users:${db.count('users',()=>true)} routes:${db.count('routes',()=>true)} buses:${db.count('buses',()=>true)} devices:${db.count('devices',()=>true)} zones:${db.count('safety_zones',()=>true)} sla:${db.count('sla_rules',()=>true)} segments:${db.count('road_segments',()=>true)} | detections:0 incidents:0`);
  return true;
}

if (require.main === module) (async()=>{ await db.init(); seed({ force: true }); await db.commit(); })().catch(e=>{ console.error(e); process.exit(1); });
module.exports = { seed, ensureProductionBootstrapAdmin };
