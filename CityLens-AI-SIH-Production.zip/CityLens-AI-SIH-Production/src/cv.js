'use strict';
/**
 * AI engine bridge. Two engines, truthfully reported:
 *  · classical-cv-v1 — local OpenCV analyzer (src/analyzer.py). Real inference.
 *  · yolo-external   — adapter for a YOLO microservice via YOLO_SERVICE_URL.
 * If the selected engine fails, the job FAILS with the real error and an
 * AI_SERVICE_FAILURE notification is raised. There is no mock fallback.
 */
const { spawn, spawnSync } = require('child_process');
const path = require('path');
const http = require('http');
const https = require('https');
const db = require('./db');
const storage = require('./storage');
const { notify, audit } = require('./audit');

const ANALYZER = path.join(__dirname, 'analyzer.py');
const TIMEOUT_MS = 180000;

function probe() {
  const py = spawnSync('python3', ['-c', 'import cv2,numpy;print(cv2.__version__)'], { timeout: 8000 });
  const cvOk = py.status === 0;
  const cvVersion = cvOk ? py.stdout.toString().trim() : null;
  const ff = spawnSync('ffmpeg', ['-version'], { timeout: 8000 });
  return {
    classical: { available: cvOk, opencv: cvVersion, video: ff.status === 0 },
    yolo: { configured: !!process.env.YOLO_SERVICE_URL, url: process.env.YOLO_SERVICE_URL || null },
  };
}

/** Sync model registry rows from a real capability probe (called at boot). */
function syncModelRegistry() {
  const p = probe();
  const upsert = (key, row) => {
    const ex = db.getBy('ai_models', 'key', key);
    if (ex) db.update('ai_models', ex.id, row); else db.insert('ai_models', { id: 'MDL-' + key, key, ...row });
  };
  upsert('classical-cv-v1', {
    name: 'CityLens Classical CV', version: 'v1', task: 'Road-surface defect detection (heuristic)',
    classes: ['pothole', 'road_crack', 'road_damage'],
    status: p.classical.available ? 'deployed' : 'unavailable',
    runtime: p.classical.available ? `OpenCV ${p.classical.opencv} · ffmpeg ${p.classical.video ? 'yes' : 'no'}` : 'python3/OpenCV missing',
    methodology: 'Deterministic contour + edge analysis; confidence derived from measured features (contrast, solidity, elongation). Not a neural network — accuracy claims are limited accordingly.',
  });
  upsert('yolo-external', {
    name: 'YOLO Road Defect Service', version: 'external', task: 'Deep-learning detection via microservice',
    classes: null,
    status: p.yolo.configured ? 'configured' : 'not_configured',
    runtime: p.yolo.configured ? p.yolo.url : 'Set YOLO_SERVICE_URL to enable (see integrations/)',
    methodology: 'Adapter to an external Ultralytics/YOLO service. Metrics come from the service itself when connected.',
  });
  return p;
}

function runClassical(filePath, outDir) {
  return new Promise(resolve => {
    const child = spawn('python3', [ANALYZER, JSON.stringify({ path: filePath, outDir })]);
    let out = '', err = '';
    const timer = setTimeout(() => { child.kill('SIGKILL'); resolve({ ok: false, error: 'Analyzer timed out (180 s)' }); }, TIMEOUT_MS);
    child.stdout.on('data', d => out += d);
    child.stderr.on('data', d => err += d);
    child.on('close', () => {
      clearTimeout(timer);
      try {
        const j = JSON.parse(out.trim().split('\n').pop());
        resolve(j.ok ? j : { ok: false, error: j.error || 'analyzer error' });
      } catch {
        resolve({ ok: false, error: 'Analyzer produced no valid output' + (err ? `: ${err.slice(-240)}` : '') });
      }
    });
  });
}

async function runExternalYolo(job) {
  const base = process.env.YOLO_SERVICE_URL;
  if (!base) return { ok: false, error: 'YOLO_SERVICE_URL not configured' };
  let sourceUrl = null;
  if (job.storageBackend && job.storageBackend.includes('private') && job.storagePathname) {
    try { sourceUrl = await storage.signedGetUrl(job.storagePathname); }
    catch (e) { return { ok: false, error: `Could not mint a signed upload URL for YOLO: ${e.message}` }; }
  } else if (/^https?:\/\//i.test(job.storedFile || '')) sourceUrl = job.storedFile;
  // Local development may deliberately run the reference service on the same
  // machine, where the absolute filePath is directly readable. Production
  // services should use sourceUrl (a short-lived signed Blob URL).
  const payload = JSON.stringify({ jobId: job.id, filename: job.filename, sourceUrl, filePath: process.env.VERCEL ? null : job.filePath, latitude: job.latitude, longitude: job.longitude, routeCode: job.routeCode });
  return new Promise(resolve => {
    const lib = base.startsWith('https') ? https : http;
    const req = lib.request(base.replace(/\/$/, '') + '/analyze', { method: 'POST', headers: { 'content-type': 'application/json' }, timeout: TIMEOUT_MS }, res => {
      let body = '';
      res.on('data', d => body += d);
      res.on('end', () => {
        if (res.statusCode !== 200) return resolve({ ok: false, error: `YOLO service HTTP ${res.statusCode}` });
        try {
          const j = JSON.parse(body);
          resolve({ ok: true, engine: 'yolo-external', framesProcessed: j.framesProcessed, avgInferenceMs: j.inferenceMs, measuredFps: j.fps, results: (j.results || []).map(r => ({ class: r.detection_type, confidence: r.confidence, frame_number: r.frame_number, bbox_norm: r.bounding_box, evidence_url: r.evidence_image || null, latitude: r.latitude, longitude: r.longitude })) });
        } catch { resolve({ ok: false, error: 'YOLO service returned invalid JSON' }); }
      });
    });
    req.on('error', e => resolve({ ok: false, error: `YOLO service unreachable: ${e.message}` }));
    req.on('timeout', () => { req.destroy(); resolve({ ok: false, error: 'YOLO service timed out' }); });
    req.end(payload);
  });
}

/** Analyze a file with the preferred engine. NO fallback-to-fake — errors are surfaced. */
async function analyze(job, outDir) {
  const engine = job.engine === 'yolo-external' ? 'yolo-external' : 'classical-cv-v1';
  const r = engine === 'yolo-external' ? await runExternalYolo(job) : await runClassical(job.filePath, outDir);
  if (!r.ok) {
    audit('system', 'AI_SERVICE_FAILURE', 'ai_job', job.id, r.error);
    notify({ kind: 'AI_SERVICE_FAILURE', severity: 'high', title: 'AI analysis failed', message: `${job.filename}: ${r.error}`, entityType: 'ai_job', entityId: job.id, forRole: 'operator' });
  }
  return r;
}

module.exports = { probe, syncModelRegistry, analyze };
