'use strict';
/** Audit trail + persistent notifications. Both are written only from real actions/events. */
const db = require('./db');
const { uid } = require('./util');

let sseEmit = () => { };
function bindEmitter(fn) { sseEmit = fn; }

/** Record an auditable action. actor: {id,email,role} | 'system'. */
function audit(actor, action, entityType, entityId, details, ip) {
  const row = {
    id: uid('AUD'),
    userId: actor && actor.id ? actor.id : null,
    userEmail: actor && actor.email ? actor.email : (actor === 'system' ? 'system' : null),
    role: actor && actor.role ? actor.role : null,
    action, entityType: entityType || null, entityId: entityId || null,
    details: details || null, ip: ip || null,
    timestamp: new Date().toISOString(),
  };
  db.insert('audit_logs', row);
  return row;
}

/**
 * Create a persistent notification for a role and/or specific user.
 * kind examples: CRITICAL_INCIDENT, TICKET_ASSIGNED, SLA_AT_RISK, SLA_BREACHED,
 * REPAIR_SUBMITTED, VERIFICATION_FAILED, INCIDENT_REOPENED, INCIDENT_VERIFIED,
 * DEVICE_OFFLINE, AI_SERVICE_FAILURE.
 */
function notify({ kind, severity = 'medium', title, message, entityType, entityId, forRole = null, forUserId = null, department = null }) {
  const row = {
    id: uid('NTF'), kind, severity, title, message: message || '',
    entityType: entityType || null, entityId: entityId || null,
    forRole, forUserId, department,
    isRead: false, archived: false,
    createdAt: new Date().toISOString(),
  };
  db.insert('notifications', row);
  sseEmit('notification', row);
  return row;
}

/** Notifications visible to a given user (their own + their role + their department + broadcast). */
function visibleTo(user) {
  return db.find('notifications', n =>
    !n.archived && (
      n.forUserId === user.id ||
      (n.forRole && n.forRole === user.role) ||
      (n.department && n.department === user.department) ||
      (!n.forUserId && !n.forRole && !n.department)
    ));
}

module.exports = { audit, notify, visibleTo, bindEmitter };
