'use strict';
/* Pages A: overview · live map · upload&analyze · detections · incidents */
(() => {
  const { $, $$, esc, ago, dt, cat, num, badge, impactBadge, empty, api, src, can, on, every } = window.CL;
  const CL = window.CL;

  /* ================= OVERVIEW ================= */
  CL.page('overview', async el => {
    const s = await api('/api/dashboard/stats');
    const kpi = (label, val, sub, cls = '') => `<div class="kpi ${cls}"><div class="kpi-l">${label}</div><div class="kpi-v">${val}</div><div class="kpi-s">${sub}</div></div>`;
    const telemetryLive = s.fleet.busesActive > 0;
    el.innerHTML = `
      <div class="page-head"><div><div class="page-title">Urban Operations Overview</div>
        <div class="page-sub">Monitoring road conditions and civic incidents across connected transport routes. Every figure is computed from stored records.</div></div></div>
      <div class="grid g4">
        ${kpi('Buses reporting', `${num(s.fleet.busesActive)}<span class="kpi-u">/${s.fleet.buses}</span>`, telemetryLive ? 'live telemetry in last 5 min' : 'no recent telemetry — connect edge client', telemetryLive ? '' : 'kpi-dim')}
        ${kpi('Detections today', num(s.ingest.detectionsToday), `${num(s.ingest.detectionsTotal)} total stored`)}
        ${kpi('Open incidents', num(s.incidents.open), `${s.incidents.critical} critical · ${s.incidents.awaitingVerification} awaiting verification`, s.incidents.critical ? 'kpi-bad' : '')}
        ${kpi('SLA breaches', num(s.tickets.breached), `${s.tickets.atRisk} at risk · ${s.tickets.open} open tickets`, s.tickets.breached ? 'kpi-bad' : 'kpi-good')}
        ${kpi('Telemetry today', num(s.ingest.telemetryToday), 'GPS pings ingested')}
        ${kpi('Coverage (fresh)', `${s.coverage.freshKm}<span class="kpi-u"> km</span>`, `${s.coverage.coveredKm} km touched · ${s.coverage.uncoveredKm} km unseen`)}
        ${kpi('Road health', s.roadHealthCityAvg == null ? '<span class="muted">n/a</span>' : `${s.roadHealthCityAvg}<span class="kpi-u">/100</span>`, s.roadHealthCityAvg == null ? 'insufficient data — needs incidents/coverage' : 'city average, formula-based', 'kpi-good')}
        ${kpi('Devices online', `${num(s.fleet.devicesOnline)}<span class="kpi-u">/${s.fleet.devices}</span>`, 'edge units with live heartbeat')}
      </div>
      <div class="grid g23" style="margin-top:14px">
        <div class="card"><div class="card-t">Live activity <span class="muted" style="margin-left:auto;font-size:11px">real events only</span></div><div id="ovFeed"></div></div>
        <div class="card"><div class="card-t">Incident pipeline</div><div id="ovPipe"></div>
          <div class="card-t" style="margin-top:16px">Getting real data in</div>
          <div class="muted" style="font-size:12.5px;line-height:1.7">
            1 · Open the <a href="/edge" target="_blank">Edge Client</a> on a phone — GPS + camera become a live scanner.<br>
            2 · <a href="#/upload">Upload &amp; Analyze</a> dashcam footage or photos (real OpenCV inference).<br>
            3 · <a href="#/telemetry">Import a GPS trace</a> to light up coverage.</div></div>
      </div>`;
    const pipe = s.incidents.byStatus;
    $('#ovPipe').innerHTML = pipe.length ? pipe.map(x => `<div class="pipe-row"><span>${badge(x.status)}</span><span class="mono">${x.n}</span></div>`).join('') : empty('No incidents yet', 'Incidents appear when the AI pipeline publishes detections.');
    const feed = el.querySelector('#ovFeed');
    const renderFeed = rows => feed.innerHTML = rows.length ? rows.map(r => `<div class="tick-item"><span class="tick-ic">${{ detection: '⌖', incident: '⚠', ticket: '🎫' }[r.type]}</span><div style="min-width:0"><div style="font-size:12.5px">${esc(r.text)}</div><div class="muted" style="font-size:11px">${ago(r.at)}</div></div></div>`).join('') : empty('No activity yet', 'This feed fills from real detections, incident transitions and ticket updates.');
    const load = async () => renderFeed((await api('/api/dashboard/activity?limit=14')).rows);
    await load();
    on('detection', load); on('incident', load); on('ticket', load);
  });

  /* ================= LIVE MAP ================= */
  CL.page('map', async el => {
    el.innerHTML = `
      <div class="page-head"><div><div class="page-title">Live GIS Command Map</div>
        <div class="page-sub">Buses appear only when real telemetry exists · zones &amp; incidents from the database.</div></div>
        <div class="page-actions" id="mapLayers"></div></div>
      <div class="map-frame"><div id="bigmap" class="map-el"></div>
        <div class="map-overlay" id="mapStat"></div></div>`;
    if (!window.L) { el.querySelector('.map-frame').innerHTML = empty('Map library unavailable', 'Leaflet CDN could not load (offline?). Data APIs still work.'); return; }
    const map = L.map('bigmap', { zoomControl: true }).setView([18.5204, 73.8567], 13);
    L.tileLayer(CL.theme === 'light' ? 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png' : 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', { attribution: '© OSM © CARTO', maxZoom: 19 }).addTo(map);
    const cluster = () => (L.markerClusterGroup ? L.markerClusterGroup({ maxClusterRadius: 46, showCoverageOnHover: false, spiderfyOnMaxZoom: true }) : L.layerGroup());
    const layers = { buses: L.layerGroup().addTo(map), incidents: cluster().addTo(map), tickets: L.layerGroup(), zones: L.layerGroup().addTo(map), routes: L.layerGroup().addTo(map), coverage: L.layerGroup() };
    $('#mapLayers').innerHTML = Object.keys(layers).map(k => `<label class="chip"><input type="checkbox" data-l="${k}" ${map.hasLayer(layers[k]) ? 'checked' : ''}/> ${k}</label>`).join('');
    $$('#mapLayers input').forEach(c => c.onchange = () => c.checked ? layers[c.dataset.l].addTo(map) : map.removeLayer(layers[c.dataset.l]));

    /* map utility controls */
    const frame = el.querySelector('.map-frame');
    frame.insertAdjacentHTML('beforeend', `<div class="map-ctl" role="group" aria-label="Map controls">
      <button data-mc="fit" title="Fit to live data">⤢</button>
      <button data-mc="home" title="Recenter city">⌂</button>
      <button data-mc="loc" title="My location">◎</button>
      <button data-mc="fs" title="Fullscreen">⛶</button></div>`);
    let locMark = null;
    frame.querySelector('[data-mc="home"]').onclick = () => map.setView([18.5204, 73.8567], 13);
    frame.querySelector('[data-mc="fit"]').onclick = () => {
      const pts = [];
      Object.values(busMarkers).forEach(m => pts.push(m.getLatLng()));
      layers.incidents.eachLayer(m => m.getLatLng && pts.push(m.getLatLng()));
      if (pts.length) map.fitBounds(L.latLngBounds(pts).pad(0.2)); else CL.toast('No live data to frame yet — telemetry and incidents will appear here.', 'err');
    };
    frame.querySelector('[data-mc="fs"]').onclick = () => document.fullscreenElement ? document.exitFullscreen() : frame.requestFullscreen?.();
    frame.querySelector('[data-mc="loc"]').onclick = () => {
      if (!navigator.geolocation) return CL.toast('This browser has no geolocation API.', 'err');
      navigator.geolocation.getCurrentPosition(pos => {
        const { latitude: la, longitude: ln, accuracy } = pos.coords;
        if (locMark) { locMark.circle.remove(); locMark.dot.remove(); }
        locMark = {
          circle: L.circle([la, ln], { radius: accuracy, color: '#3B4390', weight: 1, fillOpacity: .08 }).addTo(map),
          dot: L.circleMarker([la, ln], { radius: 6, color: '#fff', weight: 2, fillColor: '#3B4390', fillOpacity: 1 })
            .bindPopup(`<div class="pop-t">Your location</div><div class="pop-meta">±${Math.round(accuracy)} m · ${new Date(pos.timestamp).toLocaleTimeString()}</div>`).addTo(map),
        };
        map.setView([la, ln], Math.max(map.getZoom(), 15));
      }, e => {
        const why = e.code === 1 ? 'Location permission denied — allow it from the browser address-bar site settings.' : e.code === 3 ? 'Location timed out — try again near a window.' : 'Location unavailable on this device.';
        const https = (!window.isSecureContext && location.hostname !== 'localhost') ? ' Note: browsers require HTTPS (or localhost) for GPS.' : '';
        CL.toast(why + https, 'err');
      }, { enableHighAccuracy: true, timeout: 10000 });
    };

    const routes = (await api('/api/routes')).rows;
    routes.forEach(r => L.polyline(r.waypoints, { color: '#3B4390', weight: 2.5, opacity: .30 }).addTo(layers.routes));
    (await api('/api/zones')).rows.filter(z => z.active).forEach(z => L.circle([z.latitude, z.longitude], { radius: z.radiusM, color: '#3B4390', weight: 1.2, fillColor: '#3B4390', fillOpacity: .08 }).bindPopup(`<div class="pop-t">${esc(z.name)}</div><div class="pop-meta">${z.zoneType} · ${z.radiusM} m · weight ${z.priorityWeight}</div>`).addTo(layers.zones));

    const busMarkers = {};
    function busIcon(heading) {
      const dir = Number.isFinite(heading) ? `<span class="b-dir" style="transform:rotate(${Math.round(heading)}deg)"></span>` : '';
      return L.divIcon({ className: '', iconSize: [26, 26], iconAnchor: [13, 13], html: `<div class="mk-bus">${dir}<div class="b-core"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 4h14v13H5zM4 10h16M8.5 14h.01M15.5 14h.01M8 20l1-3M16 20l-1-3"/></svg></div></div>` });
    }
    async function drawBuses() {
      const rows = (await api('/api/buses?limit=200')).rows;
      const live = rows.filter(b => b.latitude != null && b.status === 'active');
      layers.buses.clearLayers();
      live.forEach(b => busMarkers[b.busCode] = L.marker([b.latitude, b.longitude], { icon: busIcon(b.heading) })
        .bindPopup(`<div class="pop-t">${b.busCode} <span class="badge b-green"><span class="dotb"></span>connected</span></div><div class="pop-meta">${esc(b.routeName || 'unassigned')} · ${b.speed ?? '—'} km/h · heading ${Number.isFinite(b.heading) ? Math.round(b.heading) + '°' : '—'}<br>last telemetry ${ago(b.lastTelemetryAt)} · source ${esc(b.telemetrySource || '—')}</div>`).addTo(layers.buses));
      $('#mapStat').innerHTML = `<b>${live.length}</b> bus(es) with live telemetry · <b>${rows.length - live.length}</b> silent <span class="muted">(shown only when they report)</span>`;
    }
    async function drawIncidents() {
      const rows = (await api('/api/incidents?open=1&limit=400')).rows;
      layers.incidents.clearLayers();
      rows.forEach(i => {
        const col = (i.impactScore || 0) >= 70 ? '#C62828' : (i.impactScore || 0) >= 45 ? '#E67E22' : '#C99700';
        L.marker([i.latitude, i.longitude], { icon: L.divIcon({ className: '', iconSize: [14, 14], iconAnchor: [7, 7], html: `<span class="mk-det ${(i.impactScore || 0) >= 70 ? 'crit' : ''}" style="color:${col}"></span>` }) })
          .bindPopup(`<div class="pop-t">${i.code} ${impactBadge(i.impactScore)}</div>
            <div class="pop-meta">${cat(i.category)} · ${badge(i.status)}<br>${esc(i.locationName || i.latitude.toFixed(4) + ', ' + i.longitude.toFixed(4))}<br>
            ${i.observationCount} obs · ${i.uniqueBusCount} buses · agg ${(i.aggConfidence * 100).toFixed(1)}%<br>last seen ${ago(i.lastSeenAt)}</div>
            <a class="btn btn-sm btn-primary" style="margin-top:7px" href="#/incidents/${i.id}">Open incident →</a>`).addTo(layers.incidents);
      });
    }
    async function drawTickets() {
      const rows = (await api('/api/tickets?open=1&limit=200')).rows.filter(t => t.latitude != null);
      layers.tickets.clearLayers();
      rows.forEach(t => L.circleMarker([t.latitude, t.longitude], { radius: 9, color: t.slaStatus === 'BREACHED' ? '#C62828' : '#3B4390', weight: 2, fillOpacity: .15 })
        .bindPopup(`<div class="pop-t">${t.code}</div><div class="pop-meta">${esc(t.department)} · ${badge(t.status)} · ${badge(t.slaStatus || 'WITHIN_SLA')}<br>due ${dt(t.dueAt)}</div><a class="btn btn-sm btn-primary" style="margin-top:7px" href="#/tickets/${t.id}">Open ticket →</a>`).addTo(layers.tickets));
    }
    async function drawCoverage() {
      const cov = await api('/api/coverage');
      layers.coverage.clearLayers();
      const col = { fresh: '#138808', moderate: '#C99700', stale: '#E67E22', uncovered: '#A8A89E' };
      cov.segments.forEach(s => L.polyline([s.a, s.b], { color: col[s.status], weight: 4, opacity: s.status === 'uncovered' ? .35 : .85 })
        .bindPopup(`<div class="pop-t">${esc(s.roadName)}</div><div class="pop-meta">${s.status} · ${s.observationCount} pings<br>last scan ${s.lastScannedAt ? ago(s.lastScannedAt) : 'never'} ${s.lastBus ? '· ' + s.lastBus : ''}</div>`).addTo(layers.coverage));
    }
    await Promise.all([drawBuses(), drawIncidents(), drawTickets(), drawCoverage()]);
    on('telemetry', t => { const m = busMarkers[t.busId]; if (m) { m.setLatLng([t.latitude, t.longitude]); if (Number.isFinite(t.heading)) m.setIcon(busIcon(t.heading)); } else drawBuses(); });
    on('incident', drawIncidents); on('ticket', drawTickets);
    every(60000, drawBuses);
  });

  /* ================= UPLOAD & ANALYZE ================= */
  CL.page('upload', async el => {
    const models = (await api('/api/models')).rows;
    const cls = models.find(m => m.key === 'classical-cv-v1');
    el.innerHTML = `
      <div class="page-head"><div><div class="page-title">Upload &amp; Analyze</div>
        <div class="page-sub">Real inference on your file — ${esc(cls ? cls.runtime : '')}. Failed analysis is reported as failed, never faked.</div></div></div>
      <div class="grid g23">
        <div class="card">
          <div class="dropzone" id="dz"><input type="file" id="file" accept=".jpg,.jpeg,.png,.mp4,.mov,.avi,.mkv,.webm" hidden/>
            <div class="dz-ic">⇪</div><div><b>Drop road footage / photo</b> or click to browse</div>
            <div class="muted" style="font-size:12px">jpg · png · mp4 · mov · mkv · webm — up to 120 MB</div></div>
          <div class="grid g2" style="margin-top:12px">
            <div class="field"><label>Capture latitude *</label><input id="ulat" class="inp" placeholder="18.5236"/></div>
            <div class="field"><label>Capture longitude *</label><input id="ulng" class="inp" placeholder="73.8478"/></div>
            <div class="field"><label>Device</label><input id="udev" class="inp" placeholder="EDGE-001"/></div>
            <div class="field"><label>Bus</label><input id="ubus" class="inp" placeholder="BUS-001"/></div>
          </div>
          <div class="field"><label>Engine</label><select id="ueng" class="inp">${models.map(m => `<option value="${m.key}" ${m.status !== 'deployed' && m.status !== 'configured' ? 'disabled' : ''}>${esc(m.name)} — ${m.status}</option>`).join('')}</select></div>
          <div style="display:flex;gap:10px;flex-wrap:wrap">
            <button id="goBtn" class="btn btn-primary" disabled>Analyze upload</button>
            <button id="tfBtn" class="btn btn-ghost" title="Renders a labelled synthetic road frame and runs the REAL analyzer on it">Generate synthetic test frame ▸ analyze</button>
          </div>
          <div class="muted" style="font-size:11.5px;margin-top:8px">GPS is required before publishing — detections are never placed by guesswork. The synthetic frame is watermarked and flagged <code>synthetic_test</code> end-to-end.</div>
        </div>
        <div class="card"><div class="card-t">Recent jobs</div><div id="jobs"></div></div>
      </div>
      <div id="jobPanel"></div>`;

    let picked = null;
    const dz = $('#dz'), fi = $('#file');
    dz.onclick = () => fi.click();
    dz.ondragover = e => { e.preventDefault(); dz.classList.add('hot'); };
    dz.ondragleave = () => dz.classList.remove('hot');
    dz.ondrop = e => { e.preventDefault(); dz.classList.remove('hot'); if (e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]); };
    fi.onchange = () => fi.files[0] && setFile(fi.files[0]);
    function setFile(f) { picked = f; dz.querySelector('b').textContent = `${f.name} · ${(f.size / 1048576).toFixed(1)} MB`; $('#goBtn').disabled = false; }

    async function refreshJobs() {
      const rows = (await api('/api/ai/jobs?limit=8')).rows;
      $('#jobs').innerHTML = rows.length ? rows.map(j => `
        <div class="job-row" data-j="${j.id}"><div style="min-width:0">
          <div style="font-size:12.5px"><b>${esc(j.filename)}</b> ${j.sourceKind === 'synthetic_test' ? '<span class="badge b-violet">synthetic test</span>' : ''}</div>
          <div class="muted" style="font-size:11px">${j.engine} · ${ago(j.createdAt)} · ${j.results ? j.results.length + ' detections' : ''} ${j.published ? '· published' : ''}</div></div>
          ${badge(j.status)}</div>`).join('') : empty('No analysis jobs yet', 'Upload footage or generate a test frame.');
      $$('#jobs .job-row').forEach(r => r.onclick = () => openJob(r.dataset.j));
    }
    await refreshJobs();
    on('job', () => { refreshJobs(); if (curJob) openJob(curJob, true); });

    let curJob = null;
    async function openJob(id, soft) {
      curJob = id;
      const { job } = await api('/api/ai/jobs/' + id);
      const p = $('#jobPanel');
      const stages = [['Ingest', true], ['Frames', job.status !== 'queued'], ['Inference', ['complete', 'failed'].includes(job.status) || job.status === 'processing'], ['Evidence', job.status === 'complete'], ['Published', !!job.published]];
      p.innerHTML = `
      <div class="card" style="margin-top:14px"><div class="card-t">Job ${job.id} ${badge(job.status)} ${job.sourceKind === 'synthetic_test' ? '<span class="badge b-violet">synthetic test frame</span>' : ''}</div>
        <div class="proc-row">${stages.map(([n, done], i) => `<div class="proc-stat ${done ? 'done' : ''} ${job.status === 'processing' && i === 2 ? 'busy' : ''}"><span>${done ? '✓' : i + 1}</span>${n}</div>`).join('<div class="proc-line"></div>')}</div>
        ${job.status === 'failed' ? `<div class="note-banner err">Analysis failed: ${esc(job.error)} — this is the real engine result (no mock fallback).</div>` : ''}
        ${job.status === 'complete' ? `
          <div class="meta-grid">
            <div class="meta-cell"><div class="dt">frames</div><b>${job.framesProcessed}</b></div>
            <div class="meta-cell"><div class="dt">avg inference</div><b>${job.avgInferenceMs ?? '—'} ms</b></div>
            <div class="meta-cell"><div class="dt">throughput</div><b>${job.measuredFps ?? '—'} fps</b></div>
            <div class="meta-cell"><div class="dt">raw upload</div><b>${(job.rawBytes / 1048576).toFixed(2)} MB</b></div>
            <div class="meta-cell"><div class="dt">evidence out</div><b>${(job.evidenceBytes / 1024).toFixed(0)} KB</b></div>
            <div class="meta-cell"><div class="dt">edge saving</div><b>${job.rawBytes ? (100 - job.evidenceBytes / job.rawBytes * 100).toFixed(1) : '—'}%</b></div>
          </div>
          <div class="grid g3" style="margin-top:12px">${(job.results || []).map(r => `
            <div class="result-card"><div class="evidence-frame">${r.evidenceCrop ? `<img src="${src(r.evidenceCrop)}" alt="evidence"/>` : '<div class="muted">no crop</div>'}</div>
              <div style="display:flex;justify-content:space-between;align-items:center;margin-top:8px"><b>${cat(r.class)}</b><span class="badge b-cyan">${(r.confidence * 100).toFixed(1)}%</span></div>
              <div class="muted" style="font-size:11px">frame ${r.frameNumber ?? 0}${r.features ? ' · ' + Object.entries(r.features).slice(0, 2).map(([k, v]) => `${k} ${v}`).join(' · ') : ''}</div>
              ${r.evidenceImage ? `<a class="muted" style="font-size:11px" href="${src(r.evidenceImage)}" target="_blank">annotated frame ↗</a>` : ''}</div>`).join('') || '<div class="muted">Engine found no defects in this file — that result is stored as-is.</div>'}</div>
          ${!job.published && (job.results || []).length ? `<div style="margin-top:14px;display:flex;gap:10px;align-items:center">
            <button id="pubBtn" class="btn btn-green">Publish ${(job.results || []).length} detection(s) → live pipeline</button>
            <span class="muted" style="font-size:12px">runs dedupe → scoring → (re)verification</span></div>` : ''}
          ${job.published ? `<div class="note-banner ok" style="margin-top:12px">Published: ${job.publishedCounts.published} new · ${job.publishedCounts.mergedIntoExisting} merged into existing incidents · ${job.publishedCounts.verificationClears} verification clear(s)</div>` : ''}
        ` : ''}
      </div>`;
      const pb = $('#pubBtn');
      if (pb) pb.onclick = async () => { pb.disabled = true; try { await api(`/api/ai/jobs/${id}/publish`, { method: 'POST' }); CL.toast('Published into the live pipeline'); openJob(id); refreshJobs(); } catch (e) { CL.toast(esc(e.message), 'err'); pb.disabled = false; } };
      if (!soft) p.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    $('#goBtn').onclick = async () => {
      if (!picked) return;
      const lat = parseFloat($('#ulat').value), lng = parseFloat($('#ulng').value);
      const btn = $('#goBtn'); btn.disabled = true; btn.textContent = 'Uploading…';
      try {
        const r = await fetch('/api/ai/analyze', { method: 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/octet-stream', 'x-filename': encodeURIComponent(picked.name), ...(isFinite(lat) ? { 'x-lat': lat } : {}), ...(isFinite(lng) ? { 'x-lng': lng } : {}), 'x-device': $('#udev').value || '', 'x-bus': $('#ubus').value || '', 'x-engine': $('#ueng').value }, body: picked });
        const d = await r.json(); if (!r.ok) throw new Error(d.error);
        CL.toast('Job queued — real inference running');
        await refreshJobs(); openJob(d.job.id);
      } catch (e) { CL.toast(esc(e.message), 'err'); }
      btn.disabled = false; btn.textContent = 'Analyze upload';
    };
    $('#tfBtn').onclick = async () => {
      const lat = parseFloat($('#ulat').value), lng = parseFloat($('#ulng').value);
      try {
        const d = await api('/api/ai/analyze', { method: 'POST', body: { testFrame: true, latitude: isFinite(lat) ? lat : undefined, longitude: isFinite(lng) ? lng : undefined, deviceId: $('#udev').value || undefined, busId: $('#ubus').value || undefined } });
        CL.toast('Synthetic frame generated — analyzing for real');
        await refreshJobs(); openJob(d.job.id);
      } catch (e) { CL.toast(esc(e.message), 'err'); }
    };
  });

  /* ================= DETECTIONS ================= */
  CL.page('detections', async el => {
    el.innerHTML = `
      <div class="page-head"><div><div class="page-title">AI Detections</div><div class="page-sub">Raw model outputs with provenance. Review actions feed model-quality metrics.</div></div>
      <div class="page-actions"><select id="fcat" class="inp inp-sm"><option value="">All categories</option>${CL.meta.categories.map(c => `<option>${c}</option>`).join('')}</select>
      <select id="fval" class="inp inp-sm"><option value="">Any review state</option><option>UNREVIEWED</option><option>CORRECT</option><option>FALSE_POSITIVE</option><option>NEEDS_REVIEW</option><option>WRONG_CATEGORY</option></select></div></div>
      <div class="card"><div class="tablewrap"><table class="tbl"><thead><tr><th>When</th><th>Category</th><th>Conf</th><th>Source</th><th>Location</th><th>Model</th><th>Incident</th><th>Review</th></tr></thead><tbody id="tb"></tbody></table></div><div id="none"></div></div>`;
    async function load() {
      const q = new URLSearchParams(); if ($('#fcat').value) q.set('category', $('#fcat').value); if ($('#fval').value) q.set('validationState', $('#fval').value);
      const d = await api('/api/detections?' + q);
      $('#tb').innerHTML = d.rows.map(r => `<tr data-id="${r.id}" class="rowlink">
        <td class="mono" style="font-size:11.5px">${dt(r.timestamp)}</td><td>${cat(r.category)}</td>
        <td class="mono">${(r.confidence * 100).toFixed(1)}%</td><td>${badge(r.sourceType)}${r.deviceId ? `<div class="muted" style="font-size:10.5px">${r.deviceId}</div>` : ''}</td>
        <td style="max-width:180px;overflow:hidden;text-overflow:ellipsis">${esc(r.locationName || r.latitude.toFixed(4) + ', ' + r.longitude.toFixed(4))}</td>
        <td class="mono" style="font-size:11px">${esc(r.modelName)}</td>
        <td>${r.incidentId ? `<a href="#/incidents/${r.incidentId}" onclick="event.stopPropagation()">↳</a>` : '—'}</td>
        <td>${badge(r.validationState)}</td></tr>`).join('');
      $('#none').innerHTML = d.rows.length ? '' : empty('No detections stored', 'Run an analysis on Upload & Analyze, or send from the Edge Client. This table only ever shows real model output.');
      $$('#tb .rowlink').forEach(tr => tr.onclick = () => openDet(tr.dataset.id));
    }
    async function openDet(id) {
      const d = await api('/api/detections/' + id);
      const r = d.detection;
      const m = CL.modal(`Detection ${r.id}`, `
        <div class="grid g2">
          <div><div class="evidence-frame big">${r.evidenceImage ? `<img src="${src(r.evidenceImage)}"/>` : '<div class="muted" style="padding:30px">No evidence frame stored for this detection</div>'}</div>
            ${r.evidenceCrop ? `<div class="muted" style="font-size:11px;margin-top:6px">crop: <a href="${src(r.evidenceCrop)}" target="_blank">open ↗</a></div>` : ''}</div>
          <div>
            <div class="meta-grid one">
              <div class="meta-cell"><div class="dt">class</div><b>${cat(r.category)}</b></div>
              <div class="meta-cell"><div class="dt">confidence</div><b>${(r.confidence * 100).toFixed(1)}%</b></div>
              <div class="meta-cell"><div class="dt">model</div><b>${esc(r.modelName)} ${esc(r.modelVersion || '')}</b></div>
              <div class="meta-cell"><div class="dt">inference</div><b>${r.inferenceMs ?? '—'} ms</b></div>
              <div class="meta-cell"><div class="dt">source</div><b>${r.sourceType} ${esc(r.deviceId || '')}</b></div>
              <div class="meta-cell"><div class="dt">gps</div><b class="mono" style="font-size:12px">${r.latitude.toFixed(5)}, ${r.longitude.toFixed(5)}</b></div>
              <div class="meta-cell"><div class="dt">privacy blur</div><b>${r.privacyStatus === 'unavailable' ? 'Unavailable — no face/plate model configured' : esc(r.privacyStatus)}</b></div>
              <div class="meta-cell"><div class="dt">incident</div><b>${d.incident ? `<a href="#/incidents/${d.incident.id}">${d.incident.code}</a>` : '—'}</b></div>
            </div>
            ${can('detection.review') ? `<div class="card-t" style="margin-top:14px">Reviewer decision</div>
            <div style="display:flex;gap:8px;flex-wrap:wrap">
              ${['CORRECT', 'FALSE_POSITIVE', 'NEEDS_REVIEW', 'WRONG_CATEGORY'].map(x => `<button class="btn btn-sm ${x === 'CORRECT' ? 'btn-green' : x === 'FALSE_POSITIVE' ? 'btn-danger' : 'btn-ghost'}" data-dec="${x}">${cat(x.toLowerCase())}</button>`).join('')}</div>
            <div class="field" style="margin-top:10px"><input id="revCmt" class="inp" placeholder="Comment (optional)"/></div>
            <div class="field" id="wcWrap" style="display:none"><select id="wcCat" class="inp">${CL.meta.categories.map(c => `<option>${c}</option>`).join('')}</select></div>` : ''}
            ${d.feedback.length ? `<div class="card-t" style="margin-top:12px">Review history</div>${d.feedback.map(f => `<div class="tl-item"><span class="tl-time">${dt(f.timestamp)}</span><b>${f.decision}</b> — ${esc(f.reviewer)} ${f.comment ? `<div class="muted">${esc(f.comment)}</div>` : ''}</div>`).join('')}` : ''}
          </div></div>`);
      m.querySelectorAll('[data-dec]').forEach(b => b.onclick = async () => {
        const dec = b.dataset.dec;
        if (dec === 'WRONG_CATEGORY' && m.querySelector('#wcWrap').style.display === 'none') { m.querySelector('#wcWrap').style.display = 'block'; return; }
        try {
          await api(`/api/detections/${id}/review`, { method: 'POST', body: { decision: dec, comment: m.querySelector('#revCmt').value || undefined, correctedCategory: dec === 'WRONG_CATEGORY' ? m.querySelector('#wcCat').value : undefined } });
          CL.toast('Review recorded'); m.remove(); load();
        } catch (e) { CL.toast(esc(e.message), 'err'); }
      });
    }
    $('#fcat').onchange = load; $('#fval').onchange = load;
    await load(); on('detection', load);
    CL.openDetection = openDet;
  });

  /* ================= INCIDENTS ================= */
  CL.page('incidents', async (el, rest) => {
    if (rest[0]) return incidentDetail(el, rest[0]);
    el.innerHTML = `
      <div class="page-head"><div><div class="page-title">Incidents</div><div class="page-sub">Deduplicated civic issues — one incident per real-world problem, many observations.</div></div>
      <div class="page-actions">
        <select id="fst" class="inp inp-sm"><option value="">All states</option>${CL.meta.incidentStates.map(s => `<option>${s}</option>`).join('')}</select>
        <select id="fct" class="inp inp-sm"><option value="">All categories</option>${CL.meta.categories.map(c => `<option>${c}</option>`).join('')}</select>
        <label class="chip"><input type="checkbox" id="fcrit"/> critical ≥70</label></div></div>
      <div class="card"><div class="tablewrap"><table class="tbl"><thead><tr><th>Code</th><th>Category</th><th>Impact</th><th>Status</th><th>Obs</th><th>Buses</th><th>Agg conf</th><th>Location</th><th>Last seen</th></tr></thead><tbody id="tb"></tbody></table></div><div id="none"></div></div>`;
    async function load() {
      const q = new URLSearchParams({ limit: 200 });
      if ($('#fst').value) q.set('status', $('#fst').value);
      if ($('#fct').value) q.set('category', $('#fct').value);
      if ($('#fcrit').checked) q.set('minImpact', 70);
      const d = await api('/api/incidents?' + q);
      $('#tb').innerHTML = d.rows.map(i => `<tr class="rowlink" onclick="location.hash='#/incidents/${i.id}'">
        <td class="mono"><b>${i.code}</b></td><td>${cat(i.category)}</td><td>${impactBadge(i.impactScore)}</td><td>${badge(i.status)}</td>
        <td class="mono">${i.observationCount}</td><td class="mono">${i.uniqueBusCount}</td><td class="mono">${(i.aggConfidence * 100).toFixed(1)}%</td>
        <td style="max-width:190px;overflow:hidden;text-overflow:ellipsis">${esc(i.locationName || '—')}</td><td class="muted">${ago(i.lastSeenAt)}</td></tr>`).join('');
      $('#none').innerHTML = d.rows.length ? '' : empty('No incidents yet', 'Incidents are created only when real detections are published into the pipeline.');
    }
    ['#fst', '#fct', '#fcrit'].forEach(s => $(s).onchange = load);
    await load(); on('incident', load);
  });

  async function incidentDetail(el, id) {
    const d = await api('/api/incidents/' + id);
    const i = d.incident;
    const FLOWNEXT = { DETECTED: ['UNDER_REVIEW', 'CONFIRMED', 'REJECTED'], UNDER_REVIEW: ['CONFIRMED', 'REJECTED'], REOPENED: ['UNDER_REVIEW', 'ASSIGNED'], ASSIGNED: ['IN_PROGRESS'], IN_PROGRESS: [], CONFIRMED: [] };
    const nexts = (FLOWNEXT[i.status] || []).filter(() => can('incident.review'));
    el.innerHTML = `
      <div class="page-head"><div><div class="page-title mono">${i.code} ${impactBadge(i.impactScore)}</div>
        <div class="page-sub">${cat(i.category)} · ${esc(i.locationName || '')} · first seen ${dt(i.firstSeenAt)} · ${badge(i.status)}</div></div>
        <div class="page-actions">
          ${nexts.map(s => `<button class="btn btn-sm ${s === 'REJECTED' ? 'btn-danger' : 'btn-primary'}" data-tr="${s}">→ ${cat(s.toLowerCase())}</button>`).join('')}
          ${i.status === 'CONFIRMED' && !i.ticketId && can('incident.assign') ? `<button class="btn btn-sm btn-green" id="mkTicket">Create work ticket</button>` : ''}
          ${i.ticketId ? `<a class="btn btn-sm btn-ghost" href="#/tickets/${i.ticketId}">Ticket ↗</a>` : ''}
        </div></div>
      <div class="grid g23">
        <div>
          <div class="card"><div class="card-t">Observations (${d.observations.length}) <span class="muted" style="margin-left:auto;font-size:11px">${i.uniqueDeviceCount} devices · ${i.uniqueBusCount} buses</span></div>
            <div class="grid g3">${d.observations.map(o => `<div class="result-card">
              <div class="evidence-frame">${o.detection && o.detection.evidenceCrop ? `<img src="${src(o.detection.evidenceCrop)}"/>` : `<div class="muted" style="font-size:11px;padding:18px;text-align:center">no frame<br>(${o.sourceType})</div>`}</div>
              <div style="display:flex;justify-content:space-between;margin-top:7px"><span class="mono" style="font-size:11px">${esc(o.deviceId || o.sourceType)}</span><b>${(o.confidence * 100).toFixed(1)}%</b></div>
              <div class="muted" style="font-size:10.5px">${ago(o.timestamp)} · ${o.distanceFromIncidentM} m from centre</div></div>`).join('')}</div>
            <div class="note-banner" style="margin-top:12px">Aggregated confidence <b>${(i.aggConfidence * 100).toFixed(1)}%</b> — ${esc(i.aggMethod || '')}. Independent devices raise it; repeat frames from one device do not.</div></div>
          <div class="card" style="margin-top:14px"><div class="card-t">Timeline</div>
            <div class="timeline">${d.history.slice().reverse().map(h => `<div class="tl-item"><span class="tl-time">${dt(h.timestamp)}</span><div><b>${h.previousStatus ? h.previousStatus + ' → ' : ''}${h.newStatus}</b> <span class="tl-user">${esc(h.changedBy)}</span>${h.note ? `<div class="tl-msg">${esc(h.note)}</div>` : ''}</div></div>`).join('')}</div></div>
        </div>
        <div>
          <div class="card"><div class="card-t">Civic Impact Score — ${i.impactScore}/100</div>
            ${(i.impactBreakdown || []).map(p => `<div class="score-row"><div style="display:flex;justify-content:space-between;font-size:12.5px"><span>${esc(p.label)}</span><span class="mono">${p.points} / ${p.max}</span></div><div class="bar"><span style="width:${p.max ? p.points / p.max * 100 : 0}%"></span></div><div class="muted" style="font-size:10.5px">${esc(p.note)}</div></div>`).join('') || '<div class="muted">Not scored yet.</div>'}
            <div class="muted" style="font-size:11px;margin-top:8px">Weights configurable in Settings · ${esc((i.impactMeta || {}).weightsVersion || '')}</div></div>
          ${d.verification ? `<div class="card" style="margin-top:14px"><div class="card-t">Repair verification</div>
            <div class="meta-grid one">
              <div class="meta-cell"><div class="dt">clear scans</div><b>${d.verification.clearObservations} / ${d.verification.required.minClearObservations}</b></div>
              <div class="meta-cell"><div class="dt">independent devices</div><b>${d.verification.independentDevices} / ${d.verification.required.minIndependentDevices}</b></div>
              <div class="meta-cell"><div class="dt">re-detections</div><b>${d.verification.redetections}</b></div></div>
            <div class="muted" style="font-size:11.5px;margin-top:8px">Closes automatically when conditions are met by real post-repair scans (threshold ${d.verification.required.confidenceThreshold}). A re-detection reopens the incident.</div>
            ${d.verification.rows.map(v => `<div class="tl-item"><span class="tl-time">${dt(v.timestamp)}</span>${v.result === 'CLEAR' ? '✅' : '❌'} ${v.result} · ${esc(v.deviceId || v.busId || 'scan')}</div>`).join('')}</div>` : ''}
          ${d.zones.length ? `<div class="card" style="margin-top:14px"><div class="card-t">Safety-zone context</div>${d.zones.map(z => `<div class="tick-item"><span>⛨</span><div><b>${esc(z.name)}</b><div class="muted" style="font-size:11px">${z.zoneType} · ${z.distanceM} m away · weight ${z.priorityWeight}</div></div></div>`).join('')}</div>` : ''}
        </div>
      </div>`;
    $$('[data-tr]').forEach(b => b.onclick = async () => {
      const note = prompt(`Note for → ${b.dataset.tr} (optional)`) || undefined;
      try { await api(`/api/incidents/${id}/transition`, { method: 'POST', body: { to: b.dataset.tr, note } }); CL.toast('Transition applied'); incidentDetail(el, id); }
      catch (e) { CL.toast(esc(e.message), 'err'); }
    });
    const mk = $('#mkTicket');
    if (mk) mk.onclick = async () => {
      const users = (await api('/api/users')).rows.filter(u => ['field', 'officer'].includes(u.role));
      const m = CL.modal('Create work ticket', `
        <div class="field"><label>Department</label><select id="tDep" class="inp">${CL.meta.departments.map(x => `<option ${x === (CL.meta.categoryDepartmentMap[i.category] || '') ? 'selected' : ''}>${x}</option>`).join('')}</select></div>
        <div class="field"><label>Assign to (optional)</label><select id="tOff" class="inp"><option value="">— unassigned —</option>${users.map(u => `<option value="${u.id}">${esc(u.name)} (${u.role}${u.department ? ' · ' + u.department : ''})</option>`).join('')}</select></div>
        <div class="field"><label>Note</label><input id="tNote" class="inp" placeholder="Instructions for the crew"/></div>`,
        `<button class="btn btn-primary" id="tGo">Create ticket</button>`);
      m.querySelector('#tGo').onclick = async () => {
        try {
          const r = await api(`/api/incidents/${id}/ticket`, { method: 'POST', body: { department: m.querySelector('#tDep').value, assignedOfficerId: m.querySelector('#tOff').value || undefined, note: m.querySelector('#tNote').value || undefined } });
          CL.toast(`Ticket ${r.ticket.code} created — SLA ${r.ticket.slaRuleName}`); m.remove(); location.hash = '#/tickets/' + r.ticket.id;
        } catch (e) { CL.toast(esc(e.message), 'err'); }
      };
    };
  }
})();
