'use strict';
/* SIH showcase pages: Impact Journey, Judge Mode, truthful System Status. */
(() => {
  const { page, api, esc, cat, dt, badge, impactBadge, empty } = CL;

  const glassTitle = (kicker, title, sub, actions='') => `<div class="showcase-head"><div><div class="show-kicker">${kicker}</div><h1>${title}</h1><p>${sub}</p></div>${actions ? `<div class="page-actions">${actions}</div>` : ''}</div>`;

  page('journey', async (el, rest) => {
    const requested = rest[0];
    let id = requested;
    if (!id) {
      const list = await api('/api/incidents?limit=100');
      const pick = list.rows.find(x => x.isDemo) || list.rows[0];
      if (!pick) {
        el.innerHTML = glassTitle('CLOSED LOOP', 'CityLens Impact Journey', 'One traceable chain from a bus observation to verified civic resolution.') + empty('No incident journey yet', 'Ingest a real detection, or run the optional <code>npm run seed:demo</code> command to create an explicitly labelled SIH demo story.');
        return;
      }
      id = pick.id;
    }
    const d = await api('/api/incidents/' + encodeURIComponent(id));
    let td = null;
    if (d.ticket?.id) { try { td = await api('/api/tickets/' + encodeURIComponent(d.ticket.id)); } catch {} }
    const inc = d.incident;
    const demo = !!inc.isDemo;
    const hist = (d.history || []).map(h => ({ at:h.timestamp, type:'incident', title:`Incident · ${h.newStatus}`, note:h.note || `${h.previousStatus || '∅'} → ${h.newStatus}` }));
    const th = (td?.history || []).map(h => ({ at:h.timestamp, type:'ticket', title:`Ticket · ${h.newStatus}`, note:h.note || `${h.previousStatus || '∅'} → ${h.newStatus}` }));
    const ev = (td?.repairEvidence || []).map(x => ({ at:x.timestamp, type:'evidence', title:`${cat(x.kind)} repair evidence`, note:x.note || `Uploaded by ${x.uploadedBy || 'field team'}` }));
    const vr = (d.verification?.rows || d.verification?.observations || []).map?.(x => ({ at:x.timestamp, type:'verify', title:`Verification · ${x.result || 'observation'}`, note:x.confidence != null ? `confidence ${(x.confidence*100).toFixed(0)}%` : 'post-repair observation' })) || [];
    const timeline = [...hist,...th,...ev,...vr].filter(x=>x.at).sort((a,b)=>new Date(a.at)-new Date(b.at));
    const before = td?.repairEvidence?.find(x=>x.kind==='before');
    const after = td?.repairEvidence?.find(x=>x.kind==='after');
    const obs = d.observations || [];

    el.innerHTML = `${glassTitle('CLOSED-LOOP CIVIC INTELLIGENCE', `${esc(inc.code)} · ${esc(cat(inc.category))}`, 'Follow the evidence, ownership and verification trail without losing provenance.', `<a class="btn btn-ghost" href="#/incidents/${inc.id}">Open incident</a>`)}
      ${demo ? '<div class="demo-ribbon"><b>DEMO DATASET</b><span>Illustrative SIH workflow records — not live municipal production data.</span></div>' : ''}
      <div class="journey-kpis">
        <div class="glass-kpi"><span>Impact</span><b>${inc.impactScore == null ? 'Not scored' : inc.impactScore}</b><small>${impactBadge(inc.impactScore)}</small></div>
        <div class="glass-kpi"><span>Independent buses</span><b>${inc.uniqueBusCount ?? 0}</b><small>${obs.length} observation${obs.length===1?'':'s'}</small></div>
        <div class="glass-kpi"><span>Department</span><b class="kpi-text">${esc(inc.department || 'Not assigned')}</b><small>${d.ticket ? esc(d.ticket.code) : 'No ticket yet'}</small></div>
        <div class="glass-kpi"><span>Outcome</span><b class="kpi-text">${esc(cat(inc.status))}</b><small>${inc.closedAt ? `Closed ${dt(inc.closedAt)}` : 'Still in workflow'}</small></div>
      </div>
      <div class="card journey-card"><div class="card-h"><div><b>Impact Journey</b><span class="muted"> · actual stored timestamps</span></div>${badge(inc.status)}</div>
        <div class="journey-track">${timeline.length ? timeline.map((x,i)=>`<div class="journey-node j-${x.type}"><div class="journey-index">${String(i+1).padStart(2,'0')}</div><div><b>${esc(x.title)}</b><p>${esc(x.note || '')}</p><time>${dt(x.at)}</time></div></div>`).join('') : '<div class="muted">No history events stored yet.</div>'}</div>
      </div>
      <div class="grid-2 journey-bottom">
        <div class="card"><div class="card-h"><b>Multi-bus evidence</b><span class="muted">${obs.length} stored</span></div><div class="obs-stack">${obs.length ? obs.map((o,i)=>`<div class="obs-row"><span class="obs-no">${i+1}</span><div><b>${esc(o.busId || 'Unknown bus')}</b><div class="muted">${esc(o.deviceId || 'Unknown device')} · ${o.confidence==null?'—':(o.confidence*100).toFixed(1)+'%'}</div></div><time>${dt(o.timestamp)}</time></div>`).join('') : '<div class="muted">No observations.</div>'}</div></div>
        <div class="card"><div class="card-h"><b>Before / after repair</b><span class="muted">field evidence</span></div>
          ${before && after ? `<div class="compare" id="compare"><img src="${esc(before.file)}" alt="Before repair evidence"><div class="compare-after" id="compareAfter"><img src="${esc(after.file)}" alt="After repair evidence"></div><input id="compareRange" type="range" min="0" max="100" value="50" aria-label="Compare before and after repair"><span class="before-tag">BEFORE</span><span class="after-tag">AFTER</span></div><div class="muted" style="margin-top:8px">Drag the slider to compare stored evidence.</div>` : `<div class="evidence-empty">${empty('Comparison unavailable','Both before and after repair evidence are required.')}</div>`}
        </div>
      </div>`;
    const range = el.querySelector('#compareRange'), afterEl = el.querySelector('#compareAfter');
    if (range && afterEl) range.oninput = () => afterEl.style.width = range.value + '%';
  });

  page('judge', async el => {
    const [stats, pub, health, incs] = await Promise.all([
      api('/api/dashboard/stats'), api('/api/public/stats'), api('/api/health'), api('/api/incidents?limit=100')
    ]);
    const demo = incs.rows.find(x=>x.isDemo);
    const steps = [
      ['01','Problem','Manual road inspection cannot continuously cover every corridor.','overview'],
      ['02','Mobile sensing',`${stats.fleet.buses} registered buses · ${stats.fleet.devicesOnline} devices reporting online.`,'fleet'],
      ['03','Edge AI','Upload a real frame/video; failures stay failures and unconfigured models stay labelled.','upload'],
      ['04','GPS + dedupe',`${pub.detections} stored detections are converted into geo-tagged observations and merged by proximity.`,'detections'],
      ['05','Impact prioritisation',`${stats.incidents.critical} open critical incident${stats.incidents.critical===1?'':'s'} right now.`,'incidents'],
      ['06','Department + SLA',`${stats.tickets.open} open work ticket${stats.tickets.open===1?'':'s'} · ${stats.tickets.atRisk} at risk · ${stats.tickets.breached} breached.`,'sla'],
      ['07','Field repair','Field workers acknowledge, start work and upload genuine JPEG/PNG evidence.','field'],
      ['08','Re-scan verification',`${stats.incidents.awaitingVerification} incident${stats.incidents.awaitingVerification===1?'':'s'} currently awaiting verification.`,'verifyq'],
      ['09','Closed loop',`${stats.incidents.closed} incident${stats.incidents.closed===1?'':'s'} verified/closed in stored data.`,'journey'],
      ['10','Governance','RBAC, audit trail, truthful system status and explicit dataset provenance.','status'],
    ];
    el.innerHTML = `${glassTitle('3-MINUTE SIH WALKTHROUGH', 'Judge Mode', 'A guided product tour that uses the real application — not a replacement slideshow.', demo ? `<a class="btn btn-primary" href="#/journey/${demo.id}">Open Demo Journey →</a>` : '')}
      ${demo ? '<div class="demo-ribbon"><b>DEMO DATASET AVAILABLE</b><span>Any seeded operational demo record is explicitly labelled in the product.</span></div>' : '<div class="info-callout">No demo dataset loaded. All values below are coming from the current database.</div>'}
      <div class="judge-grid"><div class="judge-stage"><div id="judgeStep"></div><div class="judge-nav"><button class="btn btn-ghost" id="judgePrev">← Previous</button><div class="judge-dots" id="judgeDots"></div><button class="btn btn-primary" id="judgeNext">Next →</button></div></div>
      <aside class="judge-side"><div class="sys-mini"><span>DATABASE</span><b>${esc(health.database.backend)}</b><i class="status-dot ${health.database.connected?'ok':'bad'}"></i></div><div class="sys-mini"><span>STORAGE</span><b>${esc(health.storage.backend)}</b><i class="status-dot ${health.storage.configured===true?'ok':'warn'}"></i></div><div class="sys-mini"><span>REALTIME</span><b>${esc(health.realtime.transport)}</b><i class="status-dot ok"></i></div><div class="sys-mini"><span>YOLO</span><b>${health.ai.yoloConfigured?'configured':'not configured'}</b><i class="status-dot ${health.ai.yoloConfigured?'ok':'warn'}"></i></div><p class="muted">Status lights are driven by backend configuration — not decorative mock states.</p></aside></div>`;
    let idx = 0;
    const draw = () => {
      const [n,t,desc,hash] = steps[idx];
      el.querySelector('#judgeStep').innerHTML = `<div class="judge-number">${n}</div><div class="judge-kicker">CITYLENS STORY</div><h2>${esc(t)}</h2><p>${esc(desc)}</p><a class="judge-open" href="#/${hash}">Open this module ↗</a>`;
      el.querySelector('#judgeDots').innerHTML = steps.map((_,i)=>`<button aria-label="Step ${i+1}" class="${i===idx?'on':''}" data-i="${i}"></button>`).join('');
      el.querySelectorAll('[data-i]').forEach(b=>b.onclick=()=>{idx=+b.dataset.i;draw()});
      el.querySelector('#judgePrev').disabled = idx===0; el.querySelector('#judgeNext').textContent = idx===steps.length-1?'Restart ↺':'Next →';
    };
    el.querySelector('#judgePrev').onclick=()=>{if(idx>0)idx--;draw()};
    el.querySelector('#judgeNext').onclick=()=>{idx=idx===steps.length-1?0:idx+1;draw()};
    draw();
  });

  page('status', async el => {
    const h = await api('/api/health');
    const item = (name, ok, primary, sub) => `<div class="status-card"><div class="status-icon"><i class="status-dot ${ok===true?'ok':ok===false?'bad':'warn'}"></i></div><div><span>${name}</span><b>${esc(primary)}</b><p>${esc(sub||'')}</p></div></div>`;
    el.innerHTML = `${glassTitle('TRUTHFUL OPERATIONS', 'System Status Centre', 'Configuration and connectivity states are reported honestly. “Not configured” is a valid state.')}
      <div class="status-grid">
        ${item('API',true,'Online',`Health check ${dt(h.time)}`)}
        ${item('Database',h.database.connected,h.database.backend,h.database.configured?'Persistent Neon path configured':'Local development store — configure DATABASE_URL for Vercel')}
        ${item('Object storage',h.storage.configured===true?true:null,h.storage.backend,h.storage.configured===true?'Persistent upload/evidence storage configured':(h.storage.runtimeAuth==='oidc'?'OIDC runtime mode — validated on the first Blob operation':'Connect a Vercel Blob store for persistent evidence'))}
        ${item('Authentication',h.auth.secretConfigured?true:null,'HttpOnly cookie session',h.auth.secretConfigured?'Production secret configured':'AUTH_SECRET required in production')}
        ${item('Realtime transport',true,h.realtime.transport,h.realtime.transport==='sse'?'Live SSE hub active':'Serverless-safe polling/revalidation fallback')}
        ${item('External YOLO',h.ai.yoloConfigured?true:null,h.ai.yoloConfigured?'Configured':'Not configured','Built-in analysis reports failures honestly; external adapter is optional')}
      </div>
      <div class="card architecture-card"><div class="card-h"><b>CityLens architecture</b><span class="muted">closed-loop flow</span></div><div class="arch-flow">${['Bus Cameras','Edge AI','GPS / Metadata','Secure Ingestion','Neon PostgreSQL','Deduplication','Impact Engine','Ticket + SLA','Field Repair','Re-scan Verify'].map((x,i)=>`<div class="arch-node"><span>${String(i+1).padStart(2,'0')}</span><b>${x}</b></div>${i<9?'<i>→</i>':''}`).join('')}</div></div>
      <div class="card"><div class="card-h"><b>Database record snapshot</b><span class="muted">from health endpoint</span></div><div class="record-chips">${Object.entries(h.database.records||{}).map(([k,v])=>`<div><span>${esc(cat(k))}</span><b>${CL.num(v)}</b></div>`).join('')}</div></div>`;
  });
})();
