'use strict';
/* CityLens v3 core — auth, layout, router, SSE, helpers. Real data only. */
(() => {
  const CL = window.CL = {
    user: null,
    meta: null, pages: {}, _sse: null, _handlers: {}, _pageTimers: [],
  };
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  CL.$ = $; CL.$$ = $$;

  /* ---------- utils ---------- */
  CL.esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  CL.ago = ts => { if (!ts) return '—'; const s = (Date.now() - new Date(ts)) / 1000; if (s < 60) return Math.max(1, s | 0) + 's ago'; if (s < 3600) return (s / 60 | 0) + 'm ago'; if (s < 86400) return (s / 3600 | 0) + 'h ago'; return (s / 86400 | 0) + 'd ago'; };
  CL.dt = ts => ts ? new Date(ts).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—';
  CL.cat = c => String(c || '').replace(/_/g, ' ');
  CL.num = n => (n ?? '—') === '—' ? '—' : Number(n).toLocaleString('en-IN');
  const SEVC = v => v >= 70 ? 'critical' : v >= 45 ? 'high' : v >= 25 ? 'medium' : 'low';
  CL.impactBadge = v => v == null ? '<span class="badge b-grey">unscored</span>' : `<span class="badge b-${SEVC(v)}"><span class="dotb"></span>${v}</span>`;
  const STATC = { DETECTED: 'cyan', UNDER_REVIEW: 'violet', CONFIRMED: 'medium', ASSIGNED: 'medium', IN_PROGRESS: 'high', REPAIR_SUBMITTED: 'violet', AWAITING_VERIFICATION: 'violet', VERIFIED: 'green', CLOSED: 'green', RESOLVED: 'green', REOPENED: 'critical', REJECTED: 'grey', OPEN: 'cyan', ACKNOWLEDGED: 'medium', WORK_STARTED: 'high', WITHIN_SLA: 'green', AT_RISK: 'high', BREACHED: 'critical', RESOLVED_WITHIN_SLA: 'green', RESOLVED_AFTER_SLA: 'high', online: 'green', offline: 'critical', never_connected: 'grey', active: 'green', no_telemetry: 'grey', complete: 'green', processing: 'violet', failed: 'critical', queued: 'grey', not_configured: 'grey', connection_failed: 'critical', connected: 'green', disabled: 'grey', configured_untested: 'medium', deployed: 'green', unavailable: 'critical' };
  CL.badge = s => `<span class="badge b-${STATC[s] || 'grey'}"><span class="dotb"></span>${CL.esc(CL.cat(String(s).toLowerCase()))}</span>`;
  CL.empty = (t, hint) => `<div class="empty"><div class="empty-mark">◎</div><div><b>${CL.esc(t)}</b></div><div class="muted" style="max-width:520px">${hint || ''}</div></div>`;
  CL.toast = (msg, kind = 'ok') => { const z = $('.toast-zone') || document.body.appendChild(Object.assign(document.createElement('div'), { className: 'toast-zone' })); const t = document.createElement('div'); t.className = `toast toast-${kind}`; t.innerHTML = msg; z.appendChild(t); setTimeout(() => t.classList.add('show'), 10); setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 300); }, 4200); };
  CL.modal = (title, bodyHtml, footHtml) => { $('.modal-zone')?.remove(); const z = document.createElement('div'); z.className = 'modal-zone'; z.innerHTML = `<div class="modal"><div class="modal-h"><span>${title}</span><button class="icon-btn" data-x>✕</button></div><div class="modal-b">${bodyHtml}</div>${footHtml ? `<div class="modal-f">${footHtml}</div>` : ''}</div>`; z.addEventListener('click', e => { if (e.target === z || e.target.closest('[data-x]')) z.remove(); }); document.body.appendChild(z); return z; };

  /* ---------- api ---------- */
  CL.api = async (path, opts = {}) => {
    const headers = { ...(opts.headers || {}) };
    if (!(opts.body instanceof Blob) && !(opts.body instanceof ArrayBuffer) && opts.body && typeof opts.body === 'object') { headers['content-type'] = 'application/json'; opts.body = JSON.stringify(opts.body); }
    const r = await fetch(path, { credentials: 'same-origin', ...opts, headers });
    if (r.status === 401 && !path.includes('/auth/login') && !path.includes('/auth/register')) { CL.user = null; if (CL._sse) CL._sse.close(); if (!path.includes('/auth/me')) render(); throw new Error('Authentication required'); }
    const ct = r.headers.get('content-type') || '';
    const data = ct.includes('json') ? await r.json() : await r.text();
    if (!r.ok) throw new Error((data && data.error) || `HTTP ${r.status}`);
    return data;
  };
  CL.src = p => p || '';
  CL.can = p => CL.meta && CL.meta.permissions && CL.meta.permissions.includes(p);

  /* ---------- appearance ---------- */
  CL.themeMode = localStorage.getItem('cl_theme_mode') || 'dark';
  CL.accent = localStorage.getItem('cl_accent') || 'ashoka';
  const resolvedTheme = () => CL.themeMode === 'system' ? (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light') : CL.themeMode;
  const applyTheme = () => {
    CL.theme = resolvedTheme();
    document.documentElement.setAttribute('data-theme', CL.theme);
    document.documentElement.setAttribute('data-accent', CL.accent);
    const b = $('#themeBtn'); if (b) { b.textContent = CL.themeMode === 'system' ? '◐' : CL.theme === 'dark' ? '☀' : '☾'; b.title = `Appearance: ${CL.themeMode}`; }
  };
  CL.toggleTheme = () => { const modes = ['dark','light','system']; CL.themeMode = modes[(modes.indexOf(CL.themeMode)+1)%modes.length]; localStorage.setItem('cl_theme_mode', CL.themeMode); applyTheme(); };
  CL.openAccent = () => {
    const choices = [['ashoka','Ashoka Blue'],['saffron','Saffron'],['emerald','Emerald'],['cyan','Cyan'],['violet','Violet'],['rose','Rose']];
    const z = CL.modal('Theme accent', `<div class="accent-grid">${choices.map(([k,l])=>`<button class="accent-choice ${CL.accent===k?'on':''}" data-accent-choice="${k}"><i class="accent-swatch a-${k}"></i><span>${l}</span></button>`).join('')}</div><p class="muted" style="margin:12px 0 0">Semantic critical/warning/success colours stay unchanged for safety.</p>`);
    z.querySelectorAll('[data-accent-choice]').forEach(b=>b.onclick=()=>{CL.accent=b.dataset.accentChoice;localStorage.setItem('cl_accent',CL.accent);applyTheme();z.remove();});
  };
  matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change',()=>{if(CL.themeMode==='system')applyTheme();});

  /* ---------- SSE ---------- */
  CL.on = (ev, fn) => { (CL._handlers[ev] = CL._handlers[ev] || []).push(fn); };
  CL.clearPageHooks = () => { CL._handlers = {}; CL._pageTimers.forEach(clearInterval); CL._pageTimers = []; };
  CL.every = (ms, fn) => CL._pageTimers.push(setInterval(fn, ms));
  function connectSSE() {
    if (CL._sse) CL._sse.close();
    const es = CL._sse = new EventSource('/api/stream');
    es.onerror = () => { es.close(); CL._sse = null; }; 
    for (const ev of ['notification', 'detection', 'incident', 'ticket', 'telemetry', 'device', 'bus', 'job', 'sla']) {
      es.addEventListener(ev, e => {
        let d = {}; try { d = JSON.parse(e.data); } catch { }
        if (ev === 'notification') { bumpBell(1); CL.toast(`<b>${CL.esc(d.title)}</b><br><span class="muted">${CL.esc(d.message || '')}</span>`, d.severity === 'critical' ? 'err' : 'ok'); }
        (CL._handlers[ev] || []).forEach(fn => { try { fn(d); } catch (err) { console.warn(err); } });
      });
    }
  }
  let bell = 0;
  function bumpBell(n) { bell += n; const b = $('#bellCount'); if (b) { b.textContent = bell; b.style.display = bell ? 'grid' : 'none'; } }
  CL.setBell = n => { bell = 0; bumpBell(n); };

  /* ---------- auth ---------- */
  CL.logout = async (call = true) => { if (call) { try { await CL.api('/api/auth/logout', { method: 'POST' }); } catch { } } CL.user = null; CL.meta = null; if (CL._sse) CL._sse.close(); location.hash = ''; render(); };

  /* ---------- authentication (sign in · create account) ---------- */
  const PW_RULES = [
    ['len', /.{8,}/, 'Minimum 8 characters'],
    ['up', /[A-Z]/, 'One uppercase letter'],
    ['lo', /[a-z]/, 'One lowercase letter'],
    ['num', /[0-9]/, 'One number'],
  ];
  function loginPage(mode = 'in') {
    document.body.className = 'login-body';
    const mark = `<div class="login-mark"><span class="logo-badge" style="width:46px;height:46px"><svg width="26" height="26" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round"><circle cx="16" cy="14" r="7.5"/><circle cx="16" cy="14" r="2.6" fill="currentColor" stroke="none"/><path d="M16 21.5V29M11 29h10"/><path d="M16 3.5v2.2M5.5 14h2.2M24.3 14h2.2"/></svg></span><div><div class="login-title">CityLens AI</div><div class="login-sub">Urban Intelligence &amp; Civic Operations · Pune</div></div></div>`;
    const eye = id => `<button type="button" class="pw-eye" data-eye="${id}" aria-label="Show password" aria-pressed="false">👁</button>`;
    $('#app').innerHTML = `
    <div class="login-wrap"><div class="login-grid-bg"></div><div class="auth-atmos" aria-hidden="true"></div>
      <div class="auth-shell"><section class="auth-story"><div class="story-kicker">CITYLENS AI · SIH COMMAND PLATFORM</div><h1>Turn every city bus into a <span>mobile urban intelligence sensor.</span></h1><p>Detect civic hazards, merge repeated observations, route work by department and SLA, then re-scan to verify the repair — one closed loop.</p><div class="story-flow"><b>BUS CAMERA</b><i>→</i><b>EDGE AI</b><i>→</i><b>GPS</b><i>→</i><b>INCIDENT</b><i>→</i><b>REPAIR ✓</b></div><div class="story-note">Real values only · demo records are explicitly labelled · role-based access</div></section>
      <div class="login-card auth-card">
        ${mark}
        <div class="auth-tabs" role="tablist">
          <button class="auth-tab ${mode === 'in' ? 'on' : ''}" id="tabIn" role="tab" aria-selected="${mode === 'in'}">Sign In</button>
          <button class="auth-tab ${mode === 'up' ? 'on' : ''}" id="tabUp" role="tab" aria-selected="${mode === 'up'}">Create Account</button>
        </div>

        <form class="auth-panel ${mode === 'in' ? '' : 'hide'}" id="panelIn" novalidate>
          <div class="field"><label for="lemail">Email</label><input id="lemail" class="inp" type="email" autocomplete="username" inputmode="email"/></div>
          <div class="field"><label for="lpass">Password</label><div class="pw-wrap"><input id="lpass" class="inp" type="password" autocomplete="current-password"/>${eye('lpass')}</div></div>
          <div class="login-err" id="lerr" role="alert"></div>
          <button id="lbtn" type="submit" class="btn btn-primary btn-block">Sign in</button>
          <div class="auth-alt">New to CityLens? <a href="#" data-mode="up">Create Account</a></div>
        </form>

        <form class="auth-panel ${mode === 'up' ? '' : 'hide'}" id="panelUp" novalidate>
          <div class="field"><label for="rname">Full name</label><input id="rname" class="inp" autocomplete="name" maxlength="80"/></div>
          <div class="field"><label for="remail">Email address</label><input id="remail" class="inp" type="email" autocomplete="email" inputmode="email"/></div>
          <div class="field"><label for="rpass">Password</label><div class="pw-wrap"><input id="rpass" class="inp" type="password" autocomplete="new-password"/>${eye('rpass')}</div>
            <div class="pw-meter" aria-hidden="true"><span></span><span></span><span></span><span></span></div>
            <ul class="req-list" id="reqList">${PW_RULES.map(r => `<li data-req="${r[0]}"><i>•</i>${r[2]}</li>`).join('')}</ul></div>
          <div class="field"><label for="rpass2">Confirm password</label><div class="pw-wrap"><input id="rpass2" class="inp" type="password" autocomplete="new-password"/>${eye('rpass2')}</div>
            <div class="req-hint" id="matchHint"></div></div>
          <div class="login-err" id="rerr" role="alert"></div>
          <button id="rbtn" type="submit" class="btn btn-primary btn-block">Create account</button>
          <div class="auth-alt">Already have an account? <a href="#" data-mode="in">Sign In</a></div>
        </form>
      </div></div></div>`;

    const setMode = m => loginPage(m);
    $('#tabIn').onclick = () => setMode('in');
    $('#tabUp').onclick = () => setMode('up');
    $$('.auth-alt a').forEach(a => a.onclick = e => { e.preventDefault(); setMode(a.dataset.mode); });
    $$('.pw-eye').forEach(b => b.onclick = () => {
      const i = $('#' + b.dataset.eye), show = i.type === 'password';
      i.type = show ? 'text' : 'password';
      b.setAttribute('aria-pressed', show); b.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
      b.classList.toggle('on', show); i.focus();
    });

    const enter = (user, welcome) => {
      CL.user = user;
      location.hash = '#/' + CL.defaultPage(user.role); render();
      if (welcome) setTimeout(() => CL.toast('<b>Welcome to CityLens AI.</b> Your account has been created.', 'ok'), 250);
    };

    /* sign in */
    $('#panelIn').onsubmit = async e => {
      e.preventDefault();
      const btn = $('#lbtn'), err = $('#lerr'); err.style.display = 'none';
      const email = $('#lemail').value.trim();
      if (!email || !$('#lpass').value) { err.textContent = 'Enter your email and password.'; err.style.display = 'block'; return; }
      btn.disabled = true; btn.textContent = 'Signing in…';
      try {
        const r = await CL.api('/api/auth/login', { method: 'POST', body: { email, password: $('#lpass').value } });
        enter(r.user, false);
      } catch (ex) { err.textContent = ex.message; err.style.display = 'block'; btn.disabled = false; btn.textContent = 'Sign in'; }
    };

    /* create account */
    const strength = pw => PW_RULES.filter(r => r[1].test(pw)).length;
    const paintPw = () => {
      const pw = $('#rpass').value, n = strength(pw);
      $$('.pw-meter span').forEach((sp, i) => sp.className = i < n ? 's' + n : '');
      PW_RULES.forEach(r => { const li = $(`[data-req="${r[0]}"]`); const ok = r[1].test(pw); li.classList.toggle('ok', ok); li.querySelector('i').textContent = ok ? '✓' : '•'; });
      paintMatch();
    };
    const paintMatch = () => {
      const a = $('#rpass').value, b = $('#rpass2').value, h = $('#matchHint');
      if (!b) { h.textContent = ''; h.className = 'req-hint'; return; }
      const ok = a === b; h.textContent = ok ? '✓ Passwords match' : 'Passwords do not match'; h.className = 'req-hint ' + (ok ? 'ok' : 'bad');
    };
    $('#rpass').oninput = paintPw; $('#rpass2').oninput = paintMatch;
    $('#panelUp').onsubmit = async e => {
      e.preventDefault();
      const btn = $('#rbtn'), err = $('#rerr'); err.style.display = 'none';
      const name = $('#rname').value.trim(), email = $('#remail').value.trim(), pw = $('#rpass').value;
      const fail = m => { err.textContent = m; err.style.display = 'block'; };
      if (name.length < 2) return fail('Please enter your full name.');
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return fail('Please enter a valid email address.');
      if (strength(pw) < PW_RULES.length) return fail('Password does not meet the requirements below.');
      if (pw !== $('#rpass2').value) return fail('Passwords do not match.');
      btn.disabled = true; btn.textContent = 'Creating account…';
      try {
        const r = await CL.api('/api/auth/register', { method: 'POST', body: { name, email, password: pw } });
        btn.textContent = '✓ Account created'; btn.classList.add('btn-green');
        setTimeout(() => enter(r.user, true), 350);
      } catch (ex) { fail(ex.message); btn.disabled = false; btn.textContent = 'Create account'; }
    };
  }

  /* ---------- navigation ---------- */
  const NAV = [
    ['Operations', [
      ['overview', 'Overview', '◧', ['admin', 'operator', 'officer', 'analyst']],
      ['map', 'Live GIS Map', '◎', ['admin', 'operator', 'officer', 'analyst', 'reviewer']],
      ['upload', 'Upload & Analyze', '▶', ['admin', 'operator', 'officer', 'reviewer', 'field']],
      ['telemetry', 'Telemetry', '∿', ['admin', 'operator', 'analyst']],
      ['journey', 'Impact Journey', '◇', ['admin','operator','officer','analyst','reviewer']],
      ['judge', 'Judge Mode', '★', ['admin','operator','officer','analyst','reviewer']],
    ]],
    ['Resolution', [
      ['incidents', 'Incidents', '⚠', ['admin', 'operator', 'officer', 'analyst', 'reviewer']],
      ['tickets', 'Work Tickets', '🎫', ['admin', 'operator', 'officer', 'analyst']],
      ['field', 'My Field Tasks', '🛠', ['field', 'officer']],
      ['review', 'Review Queue', '☑', ['admin', 'reviewer', 'operator']],
      ['verifyq', 'Verification', '✓', ['admin', 'operator', 'officer']],
    ]],
    ['Intelligence', [
      ['detections', 'Detections', '⌖', ['admin', 'operator', 'officer', 'analyst', 'reviewer']],
      ['coverage', 'Coverage', '▦', ['admin', 'operator', 'analyst']],
      ['analytics', 'Analytics', '∡', ['admin', 'operator', 'officer', 'analyst']],
      ['models', 'AI Models', '⬡', ['admin', 'operator', 'reviewer', 'analyst']],
      ['assistant', 'Assistant', '❯', ['admin', 'operator', 'officer', 'analyst']],
    ]],
    ['Administration', [
      ['fleet', 'Fleet & Devices', '🚌', ['admin', 'operator', 'analyst']],
      ['zones', 'Safety Zones', '⛨', ['admin', 'operator']],
      ['sla', 'SLA & Escalations', '⏱', ['admin', 'operator', 'officer']],
      ['reports', 'Reports', '⇩', ['admin', 'operator', 'officer', 'analyst']],
      ['notifications', 'Notifications', '🔔', ['admin', 'operator', 'officer', 'field', 'reviewer', 'analyst']],
      ['audit', 'Audit Log', '≣', ['admin', 'operator']],
      ['integrations', 'Integrations', '⇌', ['admin']],
      ['users', 'Users', '👥', ['admin']],
      ['status', 'System Status', '◉', ['admin','operator','analyst']],
      ['settings', 'Settings', '⚙', ['admin']],
    ]],
  ];
  CL.defaultPage = role => role === 'field' ? 'field' : role === 'reviewer' ? 'review' : 'overview';

  function shell() {
    document.body.className = '';
    const role = CL.user.role;
    $('#app').innerHTML = `
    <div class="shell">
      <aside class="sidebar" id="sidebar">
        <div class="brand"><div class="logo-badge"><svg width="21" height="21" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><circle cx="16" cy="14" r="7.5"/><circle cx="16" cy="14" r="2.6" fill="currentColor" stroke="none"/><path d="M16 21.5V29M11 29h10"/><path d="M16 3.5v2.2M5.5 14h2.2M24.3 14h2.2"/></svg></div>
          <div><div class="brand-name">CityLens AI</div><div class="brand-tag">Urban Operations Platform</div></div></div>
        <nav class="nav">
          ${NAV.map(([sec, items]) => {
            const vis = items.filter(i => i[3].includes(role));
            return vis.length ? `<div class="nav-sec">${sec}</div>` + vis.map(i => `<a class="nav-item" data-page="${i[0]}" href="#/${i[0]}"><span class="nav-ic">${i[1] === 'Notifications' ? '🔔' : i[2]}</span>${i[1]}${i[0] === 'notifications' ? '<span class="nav-badge" id="navBell" style="display:none"></span>' : ''}</a>`).join('') : '';
          }).join('')}
        </nav>
        <div class="side-foot">
          <a class="nav-item" href="/edge" target="_blank"><span class="nav-ic">📡</span>Edge Client <span class="muted" style="margin-left:auto;font-size:10px">↗</span></a>
          <div class="user-chip"><div class="avatar">${CL.esc((CL.user.name || '?')[0])}</div>
            <div style="min-width:0"><div style="font-weight:600;font-size:12.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${CL.esc(CL.user.name)}</div>
            <div class="muted" style="font-size:11px">${CL.esc((CL.meta.roles[role] || {}).label || role)}</div></div>
            </div>
          <button class="logout-item" id="logoutBtn" aria-label="Log out of CityLens">↪&nbsp; Log out</button>
        </div>
      </aside>
      <div class="main">
        <header class="topbar">
          <button class="hamb" id="hamb">☰</button>
          <div class="crumb" id="crumb">Overview</div>
          <div class="top-right">
            <div class="search-wrap"><input id="gsearch" class="inp" placeholder="Search incidents, tickets, buses…  ( / )"/><div class="search-pop" id="searchPop"></div></div>
            <button class="icon-btn" id="accentBtn" title="Theme accent">◈</button>
            <button class="icon-btn" id="themeBtn" title="Appearance">☀</button>
            <button class="icon-btn rel" id="bellBtn" title="Notifications">🔔<span class="bell-count" id="bellCount" style="display:none">0</span></button>
            <div class="clockbox"><div class="clock" id="clock">--:--</div><div class="muted" style="font-size:10px;text-align:right">IST</div></div>
          </div>
        </header>
        <main class="page" id="page"></main>
      </div>
    </div><div class="toast-zone"></div>`;
    applyTheme();
    $('#logoutBtn').onclick = () => CL.logout();
    $('#themeBtn').onclick = CL.toggleTheme; $('#accentBtn').onclick = CL.openAccent;
    $('#bellBtn').onclick = () => location.hash = '#/notifications';
    $('#hamb').onclick = () => $('#sidebar').classList.toggle('open');
    setInterval(() => $('#clock') && ($('#clock').textContent = new Date().toLocaleTimeString('en-IN', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })), 1000);
    /* global search */
    const gs = $('#gsearch'), pop = $('#searchPop'); let stimer;
    document.addEventListener('keydown', e => { if (e.key === '/' && document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') { e.preventDefault(); gs.focus(); } });
    gs.addEventListener('input', () => { clearTimeout(stimer); const q = gs.value.trim(); if (q.length < 2) { pop.style.display = 'none'; return; } stimer = setTimeout(async () => {
      try { const r = await CL.api(`/api/search?q=${encodeURIComponent(q)}`);
        const sect = (label, rows, fn) => rows.length ? `<div class="sp-sec">${label}</div>` + rows.map(fn).join('') : '';
        pop.innerHTML = sect('Incidents', r.incidents, i => `<a class="sp-item" href="#/incidents/${i.id}"><b>${i.code}</b> ${CL.cat(i.category)} ${CL.badge(i.status)}</a>`)
          + sect('Tickets', r.tickets, t => `<a class="sp-item" href="#/tickets/${t.id}"><b>${t.code}</b> ${CL.esc(t.department || '')} ${CL.badge(t.status)}</a>`)
          + sect('Buses', r.buses, b => `<a class="sp-item" href="#/fleet"><b>${b.busCode}</b> ${CL.badge(b.status)}</a>`)
          + sect('Routes', r.routes, x => `<a class="sp-item" href="#/coverage"><b>${x.routeCode}</b> ${CL.esc(x.routeName)}</a>`)
          + sect('Devices', r.devices, d => `<a class="sp-item" href="#/fleet"><b>${d.deviceCode}</b> ${CL.badge(d.connectionStatus)}</a>`) || `<div class="sp-item muted">No matches</div>`;
        pop.style.display = 'block';
      } catch { } }, 220); });
    document.addEventListener('click', e => { if (!e.target.closest('.search-wrap')) pop.style.display = 'none'; });
  }

  /* ---------- router ---------- */
  CL.page = (name, fn) => CL.pages[name] = fn;
  async function route() {
    if (!CL.user) { render(); return; }   // logged out: Back button must not reopen protected pages
    const hash = location.hash.replace(/^#\//, '') || CL.defaultPage(CL.user.role);
    const [name, ...rest] = hash.split('/');
    const fn = CL.pages[name] || CL.pages.overview || (() => { });
    CL.clearPageHooks();
    $$('.nav-item').forEach(a => a.classList.toggle('active', a.dataset.page === name));
    const nav = NAV.flatMap(s => s[1]).find(i => i[0] === name);
    $('#crumb').textContent = nav ? nav[1] : name;
    $('#sidebar').classList.remove('open');
    const el = $('#page'); el.innerHTML = '<div class="skel"></div>';
    try { await fn(el, rest); } catch (e) { el.innerHTML = CL.empty('Could not load this page', CL.esc(e.message)); }
  }
  window.addEventListener('hashchange', route);

  /* ---------- boot ---------- */
  async function render() {
    try {
      if (!CL.user) {
        const me = await CL.api('/api/auth/me');
        CL.user = me.user;
      }
      const [meta, unread] = await Promise.all([CL.api('/api/meta'), CL.api('/api/notifications?unread=1&limit=1')]);
      CL.meta = meta;
      shell();
      CL.setBell(unread.unread || 0);
      const nb = $('#navBell'); if (nb && unread.unread) { nb.textContent = unread.unread; nb.style.display = 'inline-grid'; }
      connectSSE();
      route();
    } catch (e) {
      if (/expired|Authentication/i.test(e.message)) { loginPage(); return; }
      $('#app').innerHTML = CL.empty('Cannot reach the CityLens server', `Check your connection and deployment configuration, then reload. (${CL.esc(e.message)})`);
    }
  }
  CL.render = render;
  window.addEventListener('DOMContentLoaded', () => setTimeout(render, 250));
})();
