# Deployment — CityLens AI v3

## Local development
1. Install Node.js 20+.
2. `npm install`
3. Copy `.env.example` to `.env`.
4. `npm run dev`
5. Open `http://localhost:4000/app`.

Without `DATABASE_URL`, local development intentionally uses the atomic JSON store. Without Blob, local evidence is written under `data/objects`. These fallbacks are **development-only**; the System Status page labels them honestly.

## Vercel + Neon production
Configure these Vercel Environment Variables:
- `DATABASE_URL` — Neon PostgreSQL connection string.
- `AUTH_SECRET` — long stable random secret. Required in production; the app refuses insecure random-per-instance production secrets.
- `BLOB_READ_WRITE_TOKEN` — Vercel Blob token for persistent uploads/evidence when using static-token auth. New Vercel projects can use Blob OIDC; connect the Blob store to the project.
- `BLOB_ACCESS=private` — recommended for repair/user evidence.
- `YOLO_SERVICE_URL` — optional external inference adapter.

Then deploy the repository root. `vercel.json` routes `/api/*` to the serverless Node entrypoint and serves the command centre/edge client from `public/`.

The runtime creates the small Neon compatibility tables automatically. You can also run `npm run migrate` with `DATABASE_URL` set.

## Optional SIH demo dataset
Run `npm run seed:demo` only when you intentionally want the guided SIH demonstration story. Every operational demo record is marked `isDemo=true` and `datasetLabel="Demo Dataset"`; the UI displays a DEMO DATASET ribbon. It is never seeded automatically.

## Production notes
- `HttpOnly; SameSite=Lax; Secure` session cookies are used in production. No auth token is stored in browser localStorage or added to image/SSE URLs.
- Public sign-ups are always `analyst` (read-only); privileged roles require admin changes.
- On Vercel, the UI does not depend on a long-running SSE process. Core pages already revalidate/poll; local Node retains SSE for richer realtime behaviour.
- Built-in Python/OpenCV processing requires the appropriate runtime tools. If unavailable, jobs fail honestly rather than returning fake detections. For production-scale CV, configure `YOLO_SERVICE_URL` to a dedicated inference service.
- Production never creates the known-password local demo accounts. Configure `BOOTSTRAP_ADMIN_EMAIL` and a strong `BOOTSTRAP_ADMIN_PASSWORD` for the first administrator.
