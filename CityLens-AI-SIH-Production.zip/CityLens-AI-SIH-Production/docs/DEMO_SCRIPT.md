# CityLens AI v3 — SIH Judge Demo Script

Use the optional `npm run seed:demo` dataset for a reliable presentation. It is visibly labelled **Demo Dataset** and is never inserted automatically.

## 3-minute flow
1. **Landing page (15s)** — Explain: existing public buses become mobile city scanners; edge AI sends actionable events/evidence, not a continuous raw-video firehose.
2. **Judge Mode (20s)** — Open the guided flow. Point out that values come from the backend and missing integrations remain visibly unconfigured.
3. **Live GIS / Detection (25s)** — Show the two independent bus observations of the same pothole and GPS context.
4. **Impact Journey (35s)** — Show deduplication → incident → impact score → department routing → SLA ticket as a single stored timeline.
5. **Ticket + Field workflow (30s)** — Open the work ticket and explain acknowledgement, work start and repair submission. Mention the field client keeps events in IndexedDB when offline.
6. **Before / After (25s)** — Use the repair comparison. The included demo SVGs are clearly watermarked/labelled as illustrative demo evidence, not live municipal imagery.
7. **Closed-loop verification (20s)** — Show post-repair re-scan verification and incident closure. This is the signature CityLens idea: sensing continues after the repair.
8. **System Status (10s)** — Show real Database / Blob / Auth / realtime / YOLO configuration state.

## Key sentence for judges
“CityLens does not stop at detecting a pothole. It turns repeated bus observations into an accountable SLA work order, then uses the same moving sensing network to verify that the repair actually happened.”
