# Testing

## Static/syntax/security regression check
```bash
npm run check
```
This syntax-checks project JavaScript, validates key JSON/config files, checks required production files, and rejects legacy browser bearer-token patterns.

## HTTP integration test
Run against local/disposable data:
```bash
npm run test:integration
```
It verifies health, registration, validation, HttpOnly session cookie restore, protected API access, analyst RBAC denial, duplicate-email handling, cross-origin cookie-write rejection, logout, post-logout unauthorized access, re-login, and core app assets.

## Production smoke checks after deployment
1. Create/register a user and refresh `/app` several times.
2. Navigate between Overview, Incidents, Journey, Judge Mode and System Status without re-authentication.
3. Confirm analyst calls to admin APIs return `403`, not a redirect loop.
4. Upload evidence with a permitted field/officer account and reload it through the protected Blob route.
5. Confirm Neon records remain after a fresh Vercel deployment/cold start.
6. Test 360px, 390px, 768px, 1366px and desktop widths.
7. Check browser console/network panel for uncaught errors and unexpected `401/5xx` requests.
