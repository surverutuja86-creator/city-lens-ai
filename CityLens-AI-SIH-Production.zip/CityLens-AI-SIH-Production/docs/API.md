# CityLens AI v3 — HTTP API

Base URL for local development: `http://localhost:4000`.

## Authentication
Browser sessions use the `citylens_session` **HttpOnly, SameSite=Lax** cookie. The frontend never stores its auth token in `localStorage`, and it does not append auth tokens to evidence or SSE URLs. The server still accepts `Authorization: Bearer <token>` only as a compatibility path for trusted device/API integrations.

Core auth endpoints:
- `POST /api/auth/register` — `{name,email,password}`; always creates the lowest-privilege `analyst` role and sets the session cookie.
- `POST /api/auth/login` — `{email,password}`; sets the session cookie.
- `GET /api/auth/me` — restores/validates the active session and returns user + permissions.
- `POST /api/auth/logout` — clears the session cookie.

Expected errors are explicit: `400` validation, `401` unauthenticated/expired, `403` authenticated but forbidden, `404`, `409` conflict, `413` payload too large, `415` media error, `429` rate limited, and `5xx` service failures.

## Important API groups
- `GET /api/health`, `GET /api/public/stats`
- `GET /api/dashboard/stats`, `GET /api/dashboard/activity`
- Fleet/routes/devices/telemetry: `/api/buses`, `/api/devices`, `/api/routes`, `/api/telemetry`
- Detection/incident lifecycle: `/api/detections`, `/api/incidents`, incident transitions/detail endpoints
- Tickets/SLA/repairs: `/api/tickets`, ticket transitions, `/api/tickets/:id/evidence`
- AI jobs: `POST /api/ai/analyze`, `/api/ai/jobs/:id`, `/api/ai/jobs/:id/publish`
- Coverage/analytics/reports: `/api/coverage`, `/api/analytics/*`, `/api/reports`
- Notifications/audit/users/settings/integrations: matching `/api/...` resources
- Realtime local transport: `GET /api/stream` (same-origin cookie SSE). Vercel uses request-driven refresh/polling fallback rather than requiring a permanent SSE process.

## Evidence delivery
Production repair/user evidence is stored in private Vercel Blob. Database records hold an internal protected URL (`/api/blob?key=...`). That endpoint requires a valid CityLens session and mints a short-lived Blob signed URL. Local development uses protected files under `data/objects`.

## Upload rules
Binary repair evidence is limited, MIME/magic checked, authorization checked, and persisted before the API reports success. AI input uploads preserve provenance (`sourceKind`, job/device/bus/GPS metadata). Synthetic test frames are always explicitly tagged `synthetic_test` and never represented as real municipal observations.
