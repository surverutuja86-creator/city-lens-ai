# Architecture — CityLens AI v3

```text
Bus / Field Device
  Camera + GPS + offline queue
          │ HTTPS
          ▼
Vercel Node API / Local Node Server
  ├─ HttpOnly cookie authentication + RBAC
  ├─ idempotent telemetry/detection ingest
  ├─ multi-observation deduplication
  ├─ civic impact scoring
  ├─ incident/ticket state machines
  ├─ SLA & escalation engine
  └─ repair re-verification
          │
          ├────────► Neon PostgreSQL
          │          durable operational records
          │
          ├────────► Vercel Blob
          │          uploaded footage / repair evidence
          │
          └────────► CV engine / optional YOLO service

Command Centre SPA
  Overview · GIS · Incidents · Tickets · Analytics
  Impact Journey · Judge Mode · System Status
```

## Serverless persistence model
The v2 domain code was intentionally written around a synchronous collection seam (`src/db.js`). v3 keeps those tested dedupe/SLA/state-machine algorithms intact while making persistence serverless-safe: an API request refreshes a snapshot from Neon, domain mutations are tracked, and `db.commit()` durably upserts/removes exact documents before the response is sent. This is a migration-compatible runtime layer; `schema.sql` documents the normalized relational target model.

## Security model
- Production requires a stable `AUTH_SECRET`.
- Browser sessions use secure HttpOnly cookies; bearer tokens remain only as API/device compatibility fallback.
- Passwords use scrypt with per-user salts.
- Public registration is forced to the least-privileged analyst role.
- Backend permissions are enforced independently of hidden/visible UI controls.
- Uploads validate size and JPEG/PNG magic bytes for repair evidence.

## Provenance rule
Operational values are never randomly fabricated. Missing integrations show `Not Configured`; missing data shows empty/insufficient states. Optional SIH demo records are first-class labelled demo data.
