'use strict';
require('../src/env');
// Vercel Node Function entrypoint. No long-running listener or filesystem state.
const db = require('../src/db');
const auth = require('../src/auth');
const { seed } = require('../src/seed');
const coverage = require('../src/coverage');
const cv = require('../src/cv');
const { handleRequest } = require('../server');
let ready;

async function ensureReady() {
  if (!ready) ready = (async () => {
    auth.assertConfigured();
    await db.init();
    seed();
    await db.commit();
    cv.syncModelRegistry();
    coverage.ensureSegments();
    await db.commit();
  })();
  return ready;
}

module.exports = async (req, res) => {
  try {
    await ensureReady();
    return handleRequest(req, res);
  } catch (err) {
    console.error('[vercel]', err);
    res.statusCode = 500;
    res.setHeader('content-type', 'application/json; charset=utf-8');
    res.end(JSON.stringify({ error: 'CityLens failed to initialise', detail: process.env.NODE_ENV === 'production' ? undefined : err.message }));
  }
};
